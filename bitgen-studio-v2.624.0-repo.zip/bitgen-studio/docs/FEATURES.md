# bitGen Studio — Feature Reference

bitGen Studio is a local, offline AI video and image studio: no accounts, no cloud, nothing leaves your computer. It drives ComfyUI and local models (MiniMax H3, LTX 2.5 / 2.3, Wan 2.1 / 2.2, FLUX, SDXL, Qwen Image and more) with a local LLM that writes prompts and screenplays, and puts everything around them in one window: a scene board for films and music videos, a full timeline editor, a layered image editor with vector, CAD and AI tools, parametric 3D bodies, and bridges to Blender, Daz Studio and Unreal Engine 5.8. This reference lists every feature so far, grouped by area.

## The workspace

The window, its dockers, the look of the app, projects and the files they hold.

### The window and the menu bar

- **Dockers in one window** — the left dock (system stats and settings), References, Assets, the centre dockers (Preview, Timeline, StoryBoard, Music, Stems, SFX, Image editor, ComfyUI, Prompt, Prompt chat, Console), the Queue and the Gallery. *Where:* the main window
- **The menu bar** — New project, open, save, screenshot, record, recycle bin, reset project, settings and eject every loaded model, in one row that stays put whichever docks are shown. *Where:* the row under the title bar. *Since:* 2.382.1
- **Search in dropdown lists** — every list with 8 or more items opens with a search box: type to narrow it (word starts, then the letters in order), arrows and Enter to pick, a letter opens it searching. *Where:* every dropdown list; Settings > General > Dropdown lists. *Since:* 2.478.0
- **Statusbar docker buttons** — every docker has a button that is lit while it is on screen (open or collapsed); a click hides it, another shows it again. *Where:* the statusbar. *Since:* 2.386.0
- **System stats** — live readings of the computer, with a frame and graphs (temperature, VRAM) for each graphics card. *Where:* the left dock
- **Power draw and clock speeds** — each graphics card's watts (to its limit) and clocks, the CPU's clock (and power where the computer reports it), the energy since start. *Where:* the System stats. *Since:* 2.517.0
- **The energy a job used** — Wh / kWh (graphics cards + CPU where it can be read), average and peak watts, on the job's log, its card and the project's job list. *Where:* the Queue's Done tab. *Since:* 2.517.0
- **Eject models** — unloads every loaded model to free the graphics card. *Where:* the menu bar
- **Frameless app window** — the studio opens as its own window with a custom title bar instead of a browser tab; the browser still works. *Where:* the desktop app. *Since:* 2.45.0
- **The Console** — the live log of ComfyUI, the workers and every job. *Where:* the Console docker
- **The ComfyUI docker** — ComfyUI's own interface framed inside the studio, with reload and open-in-a-browser buttons. *Where:* the ComfyUI docker. *Since:* 2.120.0
- **Tooltips everywhere, Expert mode** — every button has a tooltip; Expert mode hides the help paragraphs once you know your way around. *Where:* Settings > General
- **Space pauses anywhere** — Space pauses the canvas, the live preview or a video in the Preview docker, unless you are typing. *Where:* anywhere. *Since:* 2.410.0
- **Media viewer** — click any thumbnail to open it full-window: slide through the list, zoom at the pointer, pan, play videos and sounds, open the original. *Where:* the Gallery, Assets and References. *Since:* 2.80.0
- **Render details in the viewer** — the preview dialog shows a picture's or clip's seed, CFG, steps, sampler, model, LoRAs, size, render time and prompt. *Where:* the preview dialog

### Dockers and layout

- **Collapse and maximize** — every docker collapses to its header or is maximized; the others stay open at their own height, Esc restores. *Where:* each docker's header
- **Pins** — a pin keeps a dock's height (or a side dock's width) as it is now; it can be made smaller but not taller. *Where:* the first button in each dock's header. *Since:* 2.381.0
- **The remembered layout** — every dock's state, height, width, pin and maximize are kept in docker_status.json and loaded before anything paints. *Where:* the install folder. *Since:* 2.381.0
- **Docker configs** — save a layout for each set of dockers you open together (sizes, which are on screen, the side docks and the floating panels), up to six screen sizes per set, loaded automatically. *Where:* the Docker layout button at the right of the menu bar. *Since:* 2.392.0
- **Floating prompt docker** — the prompt docker floats as its own window; drag, resize, collapse, or dock it above, below or beside another docker. *Where:* key P. *Since:* 2.389.0
- **Floating Basic Settings and LLM tokens** — both are dockers of their own: float them, dock them as a tab in another docker, beside or inside a column, or in the left docker's list. *Where:* keys S and L. *Since:* 2.393.0
- **Named dockers** — make an empty floating docker with your own name and dock floating panels into it as tabs; it can float over the whole app or stay confined to one docker. *Where:* Docker layout > New docker. *Since:* 2.438.0
- **▣ Docker: an empty docker the others drop into** — show it with the statusbar's ▣ Docker or Ctrl+Alt+D, float main dockers with ⇱ and drag them in; an orange line shows where each lands, side by side or stacked, with splitters to size them. *Where:* the statusbar > ▣ Docker. *Since:* 2.545.0
- **Docker drag-in, Make permanent, Delete** — drag a main docker in by its own title bar; 📌 makes the ▣ docker a regular docker in the main column, 🗑 deletes it and its button; the statusbar button carries its name. *Where:* the ▣ docker's title bar. *Since:* 2.549.0
- **Docker title right-click menu** — right-click a docker you made (floating or permanent) for Rename, its layout, Make permanent / Float it again and Delete docker. *Where:* the ▣ docker's title bar. *Since:* 2.550.0
- **Named docker layouts and titles** — a named docker shows its dockers as tabs, side by side or stacked (⇆ / ⇅ in its title, or ⚙ > Layout); double-click the title to rename it in place. *Where:* a named docker's title bar. *Since:* 2.545.0
- **Dialogs in the middle** — dialogs and message boxes open in the middle of the screen, or where you last moved them. *Where:* dialog_layout.cfg. *Since:* 2.438.0
- **Panel layout file** — where every floating panel is, its size, name and tabs are kept in panel_layout.cfg. *Where:* the install folder. *Since:* 2.438.0
- **The StoryBoard floats** — the StoryBoard docker can become a window of its own, dock as a tab in a named docker, or go back under the timeline. *Where:* the StoryBoard header. *Since:* 2.456.0

### Themes and the look

- **Themes** — Dark, Darker (OLED black), Slate, Light and High contrast change the whole app, image editor included. *Where:* Settings > Themes. *Since:* 2.432.0
- **Accent colour** — any colour for the buttons, lit tabs and sliders. *Where:* Settings > Themes. *Since:* 2.432.0
- **UI size** — one slider scales every font and panel together, 60 to 175 %. *Where:* Settings > Themes. *Since:* 2.432.0
- **Customize colours** — a colour for each part of the theme (background, panels, lines, text, OK, error, hover, canvas, selected). *Where:* Settings > Themes > Customize. *Since:* 2.435.0
- **Saved themes** — save a theme as a .json in the themes folder, load it from its card, export and import it. *Where:* Settings > Themes. *Since:* 2.435.0
- **Edit theme mode** — click any element on screen to pick it and change its font, size, colours, shadows, corner radius or icon, for this element, all like it, or its whole kind. *Where:* the brush button in the top bar. *Since:* 2.443.0
- **Dialogs keep working in edit theme mode** — dialogs and popup menus take clicks and keys as usual while the mode is on. *Where:* edit theme mode. *Since:* 2.455.0
- **Editor themes** — the image editor follows the app theme, or its own Pro, Studio or Classic look. *Where:* the image editor's Window > Theme. *Since:* 2.393.0

### Projects and saving

- **Projects** — everything lives in its own project folder: outputs, video, images, sound, characters and scenes. *Where:* the menu bar's New, Open and Save
- **Save keeps everything** — the song and scenes, prompt, chat, characters, environments, references, assets, gallery, timeline and each docker's fields. *Where:* the menu bar's Save. *Since:* 2.372.0
- **Save as** — copies the whole project under a new name and opens the copy; an existing name is refused. *Where:* the menu bar. *Since:* 2.372.0
- **New project starts fresh** — the project you leave is saved first, then every docker starts empty. *Where:* the menu bar's New. *Since:* 2.371.0
- **Recycle bin** — deleted files go to the project's recycle bin; restore them, delete them for good or empty the bin. *Where:* the menu bar. *Since:* 2.374.0
- **Reset project** — empties the project and makes it again with the same name, stopping its renders and clearing its finished jobs. *Where:* the menu bar. *Since:* 2.374.0
- **Whole-project file (.bgp)** — the whole project as one XML file, self-contained with its media or as a small manifest, streamed so gigabytes are fine; opening one makes a new project. *Where:* the package button in the menu bar. *Since:* 2.436.0
- **Movie bundles** — New, Save and Load whole movies on the StoryBoard (cast, chapters, scenes and renders). *Where:* the StoryBoard's menu bar. *Since:* 2.151.0

### Assets, references, gallery and queue

- **Assets dock** — the project's images, videos and sounds; drop files on it to import them. *Where:* the Assets dock
- **Asset groups** — sort files into groups that live in the dock only; an asset can sit in several groups and the files never move. *Where:* the Assets dock
- **Select and delete assets** — tick, Ctrl-click or Shift-click tiles; delete moves them to the recycle bin, never a hard delete. *Where:* the Assets dock
- **Add tiles** — dashed add tiles open the file dialog to add pictures, videos or sounds, several at once. *Where:* References and Assets. *Since:* 2.394.0
- **References dock** — pictures, videos and sounds that ride the next generation; drag them in from the Assets or the Gallery. *Where:* the References dock
- **Gallery** — every render, with tabs for images, videos and audio; drag from it onto references, the timeline or a scene. *Where:* the Gallery
- **The queue** — one job at a time on the graphics card; pause, reorder, abort and retry, every job with its log. *Where:* the Queue. *Since:* 2.122.0
- **Pending and Done tabs** — queued, running and interrupted jobs apart from finished ones, saved with the project; resume an interrupted job. *Where:* the Queue. *Since:* 2.113.0
- **One running card** — the running render shows as one card with its prompt, mode, size, progress bar and chunk / step / time. *Where:* the Queue. *Since:* 2.400.0
- **Clear finished jobs** — removes every done, failed and cancelled job from the list without deleting files. *Where:* the Queue header
- **Abort dialog** — stop this render, retry it at the front of the queue, or stop everything. *Where:* the Abort button
- **Seeds to reuse** — every finished job's details, with a button to put its seed back in Basic Settings. *Where:* the Queue's info button. *Since:* 2.384.0
- **Live ComfyUI progress** — every video job shows which node is running and "step n of total". *Where:* the Queue, scene cards and the Generate button

### The file dialog and Save as

- **bitGen's own file dialog** — Quick access, the app and project folders, every drive with its free space, an address bar, search with wildcards, details or large icons, new folder and rename; the same on Windows, macOS and Linux. *Where:* every folder button and Choose file
- **Save as from the gallery** — every gallery tile has a save-as icon that opens the file dialog in Save As mode. *Where:* the Gallery tiles
- **Quick save** — Save in the preview dialog copies the file to the last save-as folder without a dialog, never overwriting. *Where:* the preview dialog

### Capture and remote use

- **Screenshot** — saves the app window or the whole screen to the gallery. *Where:* the menu bar (Alt+Shift+S)
- **Screen recording** — records the app or the screen as an H.264 mp4, with computer sound, microphone and a countdown. *Where:* the menu bar (Alt+Shift+R)
- **Use it from your phone** — a QR-code remote link: the phone takes photos and video, sends audio and talks to the model; everything lands in the project. *Where:* Settings > General. *Since:* 2.132.0
- **Audio visualiser** — any sound that plays fills the preview with a live visualisation (spectrum, wave, rings, particles, spectrogram). *Where:* the Preview. *Since:* 2.106.0
- **360-degree player** — a look-around view of any equirectangular video: drag to look, wheel to zoom. *Where:* the player's 360 button. *Since:* 2.119.0

### Settings, models and setup

- **The installer** — one installer per system sets up Node.js, Python, ComfyUI, the node packs and the models, tuned for your graphics card. *Where:* the setup files. *Since:* 2.331.0
- **The public beta repository** — the source with a README, the changelog of every release, contributing and security guides, issue templates and automatic tests on every push (scripts/ci-units.sh); docs/BETA.md says what is experimental and how to report a problem. *Where:* the GitHub repository, docs/BETA.md, CHANGELOG.md. *Since:* 2.477.0
- **Model catalog** — downloads the models each feature needs (video, image editing, upscaling, 3D models, Viggle and more), with a Hugging Face token and the Hugging Face CLI for big files. *Where:* Settings > Models > Model catalog
- **Node packs** — installs the ComfyUI custom node packs; a missing one is named with its pack when a job starts. *Where:* Setup > Node packs
- **Local LLM** — pick a model, start and stop its server, and rescan the folder; the running model is picked on start. *Where:* Settings > LLM. *Since:* 2.43.0
- **LLM tokens** — a live estimate of the prompt's tokens and a reply-budget slider. *Where:* the LLM tokens docker (L). *Since:* 2.148.0
- **Free VRAM before every generation** — avoids most out-of-memory failures when mixing images, music and video. *Where:* Settings > ComfyUI
- **Video accelerators** — Sage attention, Spectrum and Comfy Kitchen speed-ups per video style, with one-click installs. *Where:* Settings > ComfyUI and the video style. *Since:* 2.116.0
- **Wire any ComfyUI graph** — load a workflow, convert it to an API prompt, add your own toggles, dropdowns, sliders and text boxes and wire them to its values. *Where:* Settings > ComfyUI > Graphs. *Since:* 2.120.0
- **Graph mode** — run a wired graph from Generate with the controls you made; its load nodes fill themselves from the reference dock. *Where:* Basic Settings > Graph. *Since:* 2.120.0
- **Workflow conversion** — a UI workflow is turned into an API prompt (subgraphs and Set / Get nodes unfolded), now with ComfyUI's own frontend. *Where:* Settings > ComfyUI > Graphs. *Since:* 2.402.1
- **Model file matching** — model files a workflow names are matched to the ones your ComfyUI has, and the job log says so. *Where:* every job. *Since:* 2.345.0
- **Settings > 3D** — the engine for parametric 3D bodies and the Unreal Engine bridge settings. *Where:* Settings > 3D. *Since:* 2.471.0

## Generating video

From a single prompt to a whole film: the prompt docker, the video models, references, characters and the StoryBoard.

### The prompt docker and Generate

- **One Generate button** — the dropdown under it says what it makes: video, image, music, speech, a wired graph or a chat reply. *Where:* the prompt docker
- **Generate, Edit, Refine, Fill, Replace background, Remove** — in Image mode a dropdown on the menu bar says what Generate does to the picture in the image editor, like the Krita AI plugin; Refine gets a strength slider and the button's words follow the choice. *Where:* the prompt docker's menu bar. *Since:* 2.541.0
- **References or layers** — with the image editor closed, Edit, Refine, Replace background and Compose use the References docker's pictures (Fill and Remove leave the list); with it open, they use the selected layer, or several picked layers; a chip says which. *Where:* the prompt docker's menu bar. *Since:* 2.543.0
- **Compose** — one picture from up to three pictures: the layers picked in the image editor, or the References docker's pictures. *Where:* the prompt docker's dropdown. *Since:* 2.543.0
- **Generate modes** — Ref (reference pictures), F/L (first / last frame), Text, and Swap. *Where:* Basic Settings
- **Several jobs from one prompt** — /br/ on its own line splits the prompt into jobs that run one after another. *Where:* the prompt box
- **Enter improves the prompt** — Enter sends the prompt to the local LLM, which rewrites it. *Where:* the prompt box
- **One prompt docker for every tool** — the image editor's AI, the timeline's Fill, path layers, AI scenes, the 3D look, characters, environments and VR worlds all take their words from the prompt docker. *Where:* key P. *Since:* 2.419.0
- **Negative prompt docker** — what the picture must not have, sent with every generation; its status says whether the chosen model uses it, and the LLM's "Negative:" lines land there. *Where:* key 2, or Negative in the statusbar. *Since:* 2.419.0
- **Quick prompts** — save a prompt by its first line and pick it again from a list. *Where:* the prompt docker's menu bar. *Since:* 2.451.0
- **Generate progress** — the running job's step count above the button and a progress bar under it. *Where:* the Generate button
- **Clear the prompt** — empties the prompt box only. *Where:* the prompt docker's title bar. *Since:* 2.117.0
- **Dictation** — Speak records from the microphone and adds the words to the prompt. *Where:* the prompt docker. *Since:* 2.87.0

### The prompt chat and the local LLM

- **Prompt chat** — talk through an idea with the local LLM; prompts in its replies become blocks you can render straight away. *Where:* the Prompt chat docker. *Since:* 2.85.0
- **Save, load and clear chats** — a chat is saved as "subject - date" and listed newest first; clear wipes the window and the model's memory. *Where:* the Prompt chat. *Since:* 2.370.0
- **The LLM sees your references** — pictures in tray order with a one-line description from the local vision model, the videos and the sounds, so it writes prompts with the right tags. *Where:* the prompt chat. *Since:* 2.354.0
- **Model-specific prompting** — with an LTX or Wan style picked the LLM writes for that model. *Where:* the prompt chat. *Since:* 2.419.0
- **Speech prompts shaped for MiniMax H3** — spoken lines are put into H3's dialogue syntax with the language and the voice timbre; stray instructions are tidied away. *Where:* every prompt render
- **Read replies aloud** — speaks each answer with the chosen voice. *Where:* the prompt chat. *Since:* 2.87.0
- **Longform shot lists** — asked for something longer than one clip, the LLM writes a numbered shot list that chains. *Where:* the prompt chat. *Since:* 2.126.0
- **360 and stereo VR prompting** — the LLM is taught equirectangular and side-by-side stereo prompt rules when you ask for them. *Where:* the prompt chat. *Since:* 2.118.0

### Basic Settings and video styles

- **Basic Settings** — mode, resolution, aspect, seconds, steps, CFG, seed, format, LoRAs, ControlNet and face fix. *Where:* key S
- **Seeds** — -1 for a random seed, a number for that seed, a dice for random again, a button for the last seed used. *Where:* Basic Settings. *Since:* 2.384.0
- **Temporary LoRAs** — extra LoRAs added on top of the style's for the next renders. *Where:* Basic Settings. *Since:* 2.111.0
- **Video style card** — the picked video style with its model per phase, steps, CFG, encoder, VAE, LoRAs and negative; change a model there and it is saved into the style. *Where:* the top of Basic Settings. *Since:* 2.401.0
- **Override style** — Basic Settings decide steps, CFG, seed, model and extra LoRAs for every video model (MiniMax H3, Wan, LTX). *Where:* Basic Settings. *Since:* 2.409.0
- **Video styles** — a saved model set and workflow per mode, with phases for models that sample in stages; duplicate one to keep variants. *Where:* Settings > Video. *Since:* 2.110.0

### MiniMax H3

- **Three ways to render** — reference pictures (up to nine), first / last frame, or text alone, with native sound. *Where:* Basic Settings modes
- **Long clips joined seamlessly** — a clip longer than one run is split and joined. *Where:* Seconds
- **Long video: one run up to 30 s** — low-VRAM attention and chunked feed-forward let a MiniMax H3 clip of up to 30 seconds render in ONE generation instead of joined 15-second pieces. *Where:* the StoryBoard's ⚙ (Long video), or the MiniMax H3 Long (30 s) video style. *Since:* 2.503.0
- **More ComfyUI packs one click away** — install or update KJNodes, Yusu H3 Unified and RH DLSS 5. *Where:* Settings > ComfyUI > Video accelerators. *Since:* 2.503.0
- **Veda sparse attention** — an optional MiniMax H3 accelerator in a video style (On / Quality): about 2-3x faster than stock attention at its trained sizes, with a one-click install and its predictor in the model catalog. *Where:* Settings > Video styles; Settings > ComfyUI > Video accelerators. *Since:* 2.536.0
- **The model manager for hundreds of models** — pages that fit the docker, folder tabs (SDXL, Pony …), a 📌 This project tab, resizable cards, an info page per model with its example pictures and prompts, and Civitai details + thumbnails + examples for every model kept in one shared model_info folder. *Where:* 🧩 Models. *Since:* 2.537.0
- **Civitai into each type's folder** — ⤓ on any Civitai card downloads into the folder you picked once for that type (SDXL LoRAs, Pony models, Wan LoRAs …); Shift+click changes it; 📁 lists them (model_folders.json); 🔄 Sync fetches Civitai's details for every model on the computer. *Where:* 🧩 Models. *Since:* 2.538.0
- **Reference descriptions** — a short description under every reference picture, video and sound, kept with the project and groups, used in the mapping lines, the prompt chat and ✨ Enhance; wall / floor / furniture / light picture types. *Where:* References docker. *Since:* 2.539.0
- **References in the house builder** — drop a wall / floor picture on a wall or room (its texture in 3D, shots and panoramas, Tile size), a furniture / light picture on a piece (✨ Make it real paints it in). *Where:* 🏠 House. *Since:* 2.539.0
- **References in the image editor** — a dropped reference becomes a layer; ✨ Edit can take a reference as Picture 2. *Where:* 🖼 Image editor. *Since:* 2.539.0
- **Renders made real with references** — each Blender / Unreal object is matched to a reference picture, by its name or by hand. The first frame is made real with those pictures by an edit model, then LTX 2.3 3DREAL animates it along the render. *Where:* 🟧 Timeline Blender scene / UNREAL ▸ Render to Real, 🖼 image editor 3D and Unreal layers. *Since:* 2.540.0
- **Add-ons** — Settings ▸ Add-ons lists the optional engines (YuE2 music, Viggle native): what each is for, needs and size, and whether it is installed; ⤓ Install / ⟳ Reinstall / 🗑 Remove with the log in the tab. *Where:* Settings ▸ Add-ons. *Since:* 2.540.4
- **⟳ Reinstall and the install status** — anything already installed says ⟳ Reinstall (a downloaded model ⟳ Download again) and fetches everything again; while an install or download runs its button is disabled and a status beside it shows the step, the percentage and the seconds, then ✓ or ✗ with the reason. *Where:* Settings (Add-ons, Audio, ComfyUI, Models, Extensions), the model catalog, Civitai, the LoRA trainer and the dockers' install buttons. *Since:* 2.601.0
- **Update from GitHub** — Settings ▸ General ▸ ⟳ Updates: check GitHub for a newer version (the new commits listed), ⤓ Update now (a git clone moves to GitHub's branch with your changed files backed up; a zip install gets the changed files), npm / pip when their lists changed, ⟳ Restart now; a quiet check after start. *Where:* Settings ▸ General. *Since:* 2.540.5
- **A tidy app folder** — the app folder holds start.bat (+ package.json, README, LICENSE); the server, the workers, the settings defaults, the setup scripts and the notes are in misc\; an install updated from a zip tidies its old copies away at the first start (quick prompts kept). *Where:* the app folder. *Since:* 2.591.0
- **House builder lights** — ◯ place a light, drag its reach; move, size, colour and brightness; lit in 3D, shots and panoramas. *Where:* 🏠 House. *Since:* 2.538.0
- **Maximize beside the side dockers** — ⛶ fills the room between the open Gallery / Queue / References / Assets / left docker. *Since:* 2.538.0
- **Picture types** — mark a reference picture as person, face, clothing, first frame or last frame; a first frame switches the render to first / last frame. *Where:* the References dock. *Since:* 2.340.0
- **True CFG** — CFG above 1 adds a negative pass that strengthens only what your prompt adds. *Where:* Basic Settings. *Since:* 2.366.0
- **H3 size** — choose how sizes between H3's 32-pixel steps are handled: round down, or render larger and crop back exactly. *Where:* the StoryBoard settings. *Since:* 2.380.0
- **Speech with emotion in a character's voice** — each line carries its emotion and is spoken in the character's cloned voice; long voice clips are trimmed to an 8-second sample. *Where:* the StoryBoard and the prompt
- **Other languages** — a language tag in the quotes speaks the line in that language. *Where:* the prompt
- **H3_Viggle style** — a motion video drives the movement and a picture says who performs it. *Where:* the video style list. *Since:* 2.352.0

### LTX 2.5 and LTX 2.3

- **LTX 2.5 modes** — text, image, first / last frame, first / middle / last, lip sync, first / last lip sync, audio to video and video to video (style transfer); Auto picks by what the reference dock holds. *Where:* the LTX mode dropdown
- **⏱ Timed lines (Prompt Relay)** — `[0-2s] …` lines in an LTX prompt give each stretch of the clip its own words in one render, untimed lines cover the whole clip; ⏱ adds the next line. *Where:* the prompt docker with an LTX style, StoryBoard scenes, the timeline's AI clip (Settings ▸ Add-ons ▸ Nougan Nodes). *Since:* 2.592.0
- **Transition LoRA** — switched on automatically for the modes that travel between pictures. *Where:* the Transition dropdown
- **Official templates** — text, image and first / last frame run on ComfyUI's own templates with only built-in nodes. *Where:* LTX 2.5 styles. *Since:* 2.401.5
- **LTX on the StoryBoard** — each scene's card decides the mode, with or without the board's song. *Where:* the StoryBoard Workflow
- **LTX 2.3 modes** — text, image, first / last frame and 3D render to real. *Where:* the LTX 2.3 style. *Since:* 2.402.0
- **3D render to real (3DREAL)** — a render from Blender, a game or any CG clip becomes photoreal with the same layout and camera move; strong v2, strong or light variants. *Where:* LTX 2.3 with a reference video. *Since:* 2.402.0

### Wan 2.1 and Wan 2.2

- **Wan modes** — text, image to video, first and last frame, and a character reference (VACE). *Where:* the Wan styles
- **Graph built for you** — bitGen builds the Wan graph from ComfyUI's own nodes and picks the right model files by name. *Where:* Wan styles
- **24 fps output** — Wan's 16 fps is motion-interpolated to 24 fps to join your other clips; the reference dock's first sound is laid under it. *Where:* Wan renders

### References

- **Reference videos and sounds** — up to three of each ride a reference render; missing slots are added to the workflow when needed. *Where:* References > Video and Sound. *Since:* 2.353.0
- **Choose the frames of a reference video** — a looping preview, a zoomable filmstrip and a selection box; Apply cuts exactly those frames. *Where:* References > Video
- **Append / Prepend** — render a new part that starts on the video's last frame (or ends on its first) and joins it, always as first / last frame. *Where:* the video's Use dropdown. *Since:* 2.388.0
- **Timeline capture** — the playhead's frame from any layer becomes a first frame, last frame or reference. *Where:* the timeline's capture buttons. *Since:* 2.117.0
- **Qwen Image 2.1 reads the dock** — pictures are sent in order and named in the prompt from their types. *Where:* image generation. *Since:* 2.340.0

### Characters, locations and environments

- **Characters** — a name, details, a character sheet (front / side / back) and a voice clip; its @tag brings the sheet and voice into prompts. *Where:* the StoryBoard > Characters
- **A character from one picture** — upload a photo or render and a reference sheet is generated. *Where:* the new-from-picture button
- **Actors** — choose who is in the current scene. *Where:* the Actors button
- **Clothing and identity models** — clothing entries follow the character; each keeps a dataset folder for identity models. *Where:* the character
- **360-degree environments** — locations as panoramas with a camera and a scene range, projected to a flat view for continuity. *Where:* the StoryBoard > Environments. *Since:* 2.142.0

### The StoryBoard (scene board) and films

- **Create screenplay** — describe a story and the LLM writes the scenes, with the characters speaking their lines. *Where:* the prompt docker
- **Scene count** — type how many scenes, or let the project, your request or the LLM decide. *Where:* the StoryBoard
- **How each scene follows** — Ref (a new shot), First (exactly on a frame of the take before), Cont (that frame with the cast sheets), Trans (from that frame to the new location). *Where:* each scene card
- **Render a scene or the selected ones** — rendering continues in the background while you edit. *Where:* the scene's play button, Render selected
- **Filmstrip** — click a frame of a take to make it the next scene's first frame. *Where:* under each take
- **The take bar** — watch, keep, redo, swap the character, or upscale a take. *Where:* under the board
- **Make a first frame** — Qwen Image 2.1 makes a scene's opening picture from the characters, a location and props. *Where:* the scene's First / Last slots. *Since:* 2.337.0
- **Compile** — joins the rendered takes into one film in scene order. *Where:* the StoryBoard's menu bar
- **The Scenes dropdown** — the board in a dropdown, with a scene picker showing each scene's state. *Where:* the StoryBoard. *Since:* 2.391.1
- **Scene progress** — "rendering step n of total" with a bar and time on each card. *Where:* the scene card. *Since:* 2.391.1
- **Render settings** — size, steps, LoRAs, accelerators, the upscaler and the tail frames. *Where:* the StoryBoard's settings button
- **Scene seeds** — random for each scene or one seed for all; each card has its own seed box. *Where:* the StoryBoard settings. *Since:* 2.384.0
- **Render size** — the StoryBoard setting, else Basic Settings, else the app default; the job notes say which. *Where:* the StoryBoard
- **StoryBoard pictures** — a picture per scene from its prompt with any image model, using character sheets, locations and references; use it as the first or last frame. *Where:* the StoryBoard bar. *Since:* 2.456.0
- **Make all missing pictures** — renders every scene picture that is not there yet. *Where:* the StoryBoard bar. *Since:* 2.456.0
- **The info line** — the StoryBoard's latest message, in full on hover. *Where:* the bottom of the StoryBoard. *Since:* 2.391.0
- **Motion slot** — with H3_Viggle, each scene takes a motion video. *Where:* the scene card. *Since:* 2.352.0

### Music videos and lip sync

- **Load a song** — its waveform opens auto-segmented; one scene per segment. *Where:* the StoryBoard's Audio
- **Create music video** — the writer uses the song's segments as scenes and makes the characters sing. *Where:* the prompt docker
- **Lip sync per scene** — every scene lip-syncs its own window of the song. *Where:* the music-video board
- **The transcript decides** — a timed transcript of the song says which scenes are sung and puts the words in the prompt. *Where:* the music-video board. *Since:* 2.356.0
- **Scenes at their song time** — each take lands on the timeline at the time its part of the song starts. *Where:* Timeline settings
- **Bridge scenes** — short transitions between song segments, rendered by the model or drawn as standard transitions. *Where:* the song strip's Transition option

### Character swap

- **Swap a character in footage** — a new person in existing footage; the performance, camera, background and sound stay. *Where:* Basic Settings > Swap
- **Swap a take** — swap the character of a rendered scene into its next take. *Where:* the take bar
- **The Swap dialog** — for whole movies: load a video of any length, auto-segment it, swap each piece, keep and compile. *Where:* the StoryBoard's Swap button
- **Swap quality** — Full, Best or Fast. *Where:* the Swap dialog. *Since:* 2.336.0
- **Write prompt** — the vision model and LLM write a swap prompt from the picture and the video. *Where:* the Swap dialog. *Since:* 2.335.0
- **LTX Ripple engine** — a first frame with the new character carried through the clip. *Where:* the Swap dialog's Engine. *Since:* 2.339.0
- **Viggle engines** — Viggle-Animate through ComfyUI, or bitGen's own native engine that keeps the model loaded between segments. *Where:* the Swap dialog's Engine. *Since:* 2.344.0
- **Several first frames** — make up to four first frames per segment and pick one. *Where:* the Swap dialog. *Since:* 2.348.0
- **Safe mode** — a black take is rendered again with everything that can blacken it switched off. *Where:* the Swap dialog's settings. *Since:* 2.350.0
- **VR swap** — swaps a person in 360 or 180-degree footage through a virtual camera; stereo eyes rebuilt from depth. *Where:* the Swap dialog's VR line

### VR

- **VR World** — a performer inside a 360 or 180-degree picture: aim the camera, add the performer's pictures, sound and prompt, render with VR metadata. *Where:* the StoryBoard's VR World button
- **Lock the background** — outside the performer both eyes show the picture itself. *Where:* VR World

### Upscaling and enhancing

- **SeedVR2 upscaling** — upscale a video to 720p-4K or by a factor, with colour match, temporal split and denoise. *Where:* the preview bar. *Since:* 2.400.0
- **DLSS 5 enhance, upscale and frame generation** — NVIDIA DLSS 5 neural rendering on a video (default / natural / cinematic), upscaling to 1x DLAA, 1.5x-3x or 1K-8K, and optional frame generation up to 6x the frame rate; RTX only. *Where:* the preview bar's ⚡ DLSS 5, and the StoryBoard's ⚙ Upscaler on the board. *Since:* 2.504.0
- **Enhance the selected video** — opens the upscaler for the last video you clicked. *Where:* the prompt docker. *Since:* 2.401.0
- **Upscale on the board** — a take you like sent through the StoryBoard's upscaler, or SeedVR2 at the upscale resolution; optionally every render. *Where:* the StoryBoard settings

### Sound effects (the SFX dock)

- **Add sounds and videos** — audio files and the sound of video files, kept as 48 kHz WAV. *Where:* the SFX dock
- **Cut sounds** — select on the waveform, set a fixed duration box, keep or delete the selection with click-free fades, undo. *Where:* the SFX dock
- **A range on one layer** — the position marker at the start, Shift+click on the layer at the end: the range on that layer; ✂ Cut removes all of it from that layer only, ↶ / Ctrl+Z undoes. *Where:* the timeline's layers. *Since:* 2.603.0
- **Timeline undo / redo** — every edit to the timeline is a step: ↶ / ↷ in its menu bar, Ctrl+Z / Ctrl+Shift+Z over the layers. *Where:* the timeline. *Since:* 2.603.0
- **To the gallery and assets** — every cut is copied to the gallery; send it to the Sound assets. *Where:* the SFX dock
- **Speech and dialog** — text typed, pasted or written by the LLM read aloud by OmniVoice or Ming-3.0 TTS, one voice or a cast (a voice and an emotion per speaker, from "Name (emotion): line"), sound tags, pauses; saved as WAV or MP3 into the Audio assets. *Where:* the SFX dock ▸ 🗣 Speech & dialog. *Since:* 2.621.0
- **Speech with emotion** — neutral, happy, sad, angry, fearful, disgusted, surprised: Ming-3.0 TTS's emotion task (with cloned voices too); with OmniVoice the pace, a voice recorded in that mood ("Name.happy") and the sound tags. *Where:* the SFX dock ▸ 🗣 Speech & dialog. *Since:* 2.621.0
- **Metadata in the speech file** — the title, the date and time, the description, the text and the voices written into the WAV (INFO) or MP3 (ID3). *Where:* the SFX dock ▸ 🗣 Read & save. *Since:* 2.621.0

## Images

Still pictures from text and references, ControlNet guidance, face fixing and AI edits.

### Image generation

- **Image styles** — FLUX.2 Klein, SDXL, Pony, Illustrious, Z-Image, Qwen Image and more, each a saved workflow, model set and LoRA stack. *Where:* Settings > Image. *Since:* 2.66.0
- **ComfyUI starts for you** — Generate Image launches ComfyUI when it is not running. *Where:* Generate. *Since:* 2.73.0
- **Model dropdowns from ComfyUI** — model, VAE, encoder and LoRA fields list what ComfyUI can actually load. *Where:* Settings > Image. *Since:* 2.71.0
- **Several at once** — up to eight pictures per press. *Where:* Generate
- **Image editing styles** — edit a picture from up to three references (FLUX.2 Klein edit) or more with Qwen Image 2.1 edit. *Where:* Generate with the image mode. *Since:* 2.69.0
- **FLUX 3 Image Klein** — Black Forest Labs' 5.6B open model as three styles: distilled (fast), base (cfg 3.5) and edit (up to 4 reference pictures); the text styles switch to the edit graph when the reference dock has pictures. *Where:* the image style dropdown, Settings > Setup for the models. *Since:* 2.502.0
- **Krea 2** — Krea's 12B open image model as four styles: Turbo (8 steps) and Raw (52 steps, a negative prompt), each as safetensors or GGUF. *Where:* the image styles. *Since:* 2.516.0
- **Anima** — CircleStone Labs' 2B anime / illustration model as two styles (Aesthetic v1.1, Base v1.0; 30 steps, cfg 4). *Where:* the image styles. *Since:* 2.517.0
- **Queue presets** — Normal / Quiet (overnight) / Eco / Cool-down / Max performance / Custom: a GPU power limit, a rest between jobs, waits while a card is hot, throttling warnings. *Where:* the menu bar's ⏱. *Since:* 2.518.0
- **Model manager** — your models + LoRAs as cards (thumbnail, rating, release date, type, category, keywords; the description card on hover), select a model + LoRAs, override the style with them, ✚ a new style from one, ✎ edit a card, 🔍 look it up on Civitai. *Where:* 🧩 Models in the statusbar. *Since:* 2.518.0
- **Civitai downloads** — search civitai.red / civitai.com and download straight into the right ComfyUI folder with its card. *Where:* the Model manager's Civitai tab; the key in Settings ▸ General. *Since:* 2.518.0
- **Energy cost** — the price per kWh: every job's ⚡ card, its [power] line and the energy since start show the cost. *Where:* Settings ▸ General. *Since:* 2.518.0
- **Testing docker** — the tests a version needs, ticked as they are done (many by themselves), notes, 💾 a log to upload. *Where:* Settings ▸ General ▸ 🧪 Testing. *Since:* 2.518.0
- **Setup asks for your hardware** — graphics card (from a list), RAM and CPU when setup cannot find them; "Not right?" changes them. *Where:* setup's first page. *Since:* 2.519.0
- **Packages** — Editor (no AI) / + small AI / + mid-size AI / Everything, picked for your card; what you'll be able to use (✓ ~ ✗, add later) and the download before you install. *Where:* setup's Your package page; setup-cli --packages. *Since:* 2.519.0
- **Daily supply charge** — the fixed daily charge on the bill: a job's cost adds its share for the time it ran. *Where:* Settings ▸ General ▸ Energy cost. *Since:* 2.519.0
- **LoRA trainer** — train a LoRA from your pictures with ai-toolkit (Ostris): nine base models (Z-Image Turbo, FLUX, Qwen-Image, SDXL, SD 1.5, Chroma, Wan 2.1…), trigger word, rank, steps, dataset with captions (or the assistant's), editable YAML, live steps / loss / samples; the LoRA lands in ComfyUI's loras/trained with its card; export the job as a zip. *Where:* statusbar 🎓 LoRA. *Since:* 2.520.0
- **Peak / off-peak prices** — a peak price and peak time windows (days + times, through midnight too); every other minute is off-peak; jobs split peak and off-peak energy. *Where:* Settings ▸ General ▸ Energy cost. *Since:* 2.520.0
- **Usage log** — every job's energy, peak share, cost and remote GPU, day by day; ranges, totals, CSV. *Where:* Settings ▸ General ▸ 📊 Usage…, or click the ⚡ statusbar figure. *Since:* 2.520.0
- **Remote GPU** — use another machine's ComfyUI, a RunPod pod (list / start / stop, its proxy) or an SSH tunnel; ✓ Test; Use it / Use this computer. *Where:* Settings ▸ Remote GPU. *Since:* 2.520.0
- **This computer & package** — your hardware, the package installed, what each package lets you use; ✎ Not right?; ⬆ Upgrade to a bigger package without setup. *Where:* Settings ▸ Models. *Since:* 2.520.0
- **Grouped downloads** — a checkbox per model group, with its file count and size. *Where:* setup's models page; Settings ▸ Models ▸ Model downloads. *Since:* 2.520.0
- **Checkpoint fine-tune** — every weight of a picture model (Lumina 2, Flex.1, FLUX.2 klein, SDXL) with ai-toolkit, parameter swapping for less VRAM; joined into one .safetensors in diffusion_models/trained. *Where:* 🎓 LoRA ▸ Type. *Since:* 2.521.0
- **LLM fine-tune** — the assistant on your own chats with Unsloth (Qwen3.5 0.8B-9B, Gemma 4, Qwen3.8 27B; LoRA / QLoRA / full); typed or imported (JSONL / JSON / CSV) examples; a .gguf in the LLM folder. *Where:* 🎓 LoRA ▸ Type. *Since:* 2.521.0
- **Vision fine-tune** — the vision model on pictures + answers (Qwen3.5 / Gemma 4 vision); the .gguf + mmproj in the vision folder. *Where:* 🎓 LoRA ▸ Type. *Since:* 2.521.0
- **Bake a LoRA** — a finished LoRA merged into its base model as a new checkpoint (ComfyUI), any card. *Where:* 🎓 LoRA ▸ Run & samples. *Since:* 2.521.0
- **FLUX.2 klein LoRAs** — the FLUX.2 klein base 4B as a LoRA base model. *Where:* 🎓 LoRA ▸ Base model. *Since:* 2.521.0
- **Bug report** — Ctrl+Alt+Shift+B: a screenshot of the window (✏ / ▭ marks), title, severity, where, what happened / expected, steps (⤵ the recorded clicks and keys - never what was typed), with the logs, system + settings (secrets hidden), page errors and failed requests; 💾 saves one .zip to send; earlier reports ⤓ / 🗑. *Where:* anywhere (Ctrl+Alt+Shift+B); Settings ▸ General ▸ 🐞 Report a bug…. *Since:* 2.522.0
- **The loader follows the model file** — a style's .safetensors or .gguf model gets the matching ComfyUI loader (Load Diffusion Model / the GGUF loader) automatically - a GGUF style renders a .safetensors fine-tune and the other way round. *Where:* every picture style. *Since:* 2.523.0
- **🏠 House builder** — draw a floor plan in metres (rooms, walls, doors, windows, sliding doors, garage doors, stairs between floors), furnish it from a 38-piece library, set floor / wall materials and the sun by the hour, see it in 3D, then use it as a location: 📍 a 360° panorama -> a Location, 📷 shots with depth + normal maps -> Image assets, ✨ Make it real (the shot -> a photoreal picture through an edit style), ⤓ .obj for Blender / Unreal. *Where:* 🏠 House on the statusbar. *Since:* 2.524.0
- **A model is found in whichever ComfyUI folder holds it** — a style's diffusion model sitting in models/checkpoints (or another subfolder) is loaded through Load Checkpoint / the name ComfyUI lists, instead of failing "Value not in list"; a model in no folder gets a message saying where to put it. *Where:* every picture, video and music job. *Since:* 2.525.0
- **Workspaces** — a Workspace dropdown in the menu bar: Basic, Image editing, Video editing, Music video, Expert. Each shows the dockers that work needs, hides the buttons it doesn't (nothing disabled) and remembers your own changes; ↺ resets one. *Where:* the menu bar. *Since:* 2.526.0
- **🩺 Style doctor** — one click makes a small test picture with every image style (Quick: 512 × 512, 4 steps; or Real) and shows a pass / fail table: the failing log line and what to do (a model ComfyUI does not list and which folder it belongs in, a missing node pack, ComfyUI not running, out of VRAM, a damaged file, a mismatched text encoder). ■ Stop, ↻ one again, ⤓ the report as .md. *Where:* 🩺 in the menu bar. *Since:* 2.527.0
- **🧍 Characters in House shots** — a Person tool in the House builder: a mannequin with a pose, height, facing, the project character it stands for and an optional LoRA; it is in the 3D view, shots, depth / normal maps and 360°s, and ✨ Make it real swaps it for the character - their picture goes with the shot and the prompt names who is where. *Where:* 🏠 House -> 🧍. *Since:* 2.528.0
- **House builder extras** — a roof (flat / gable / hip), a floor-plan picture to trace over (with a two-point scale), 🪄 furnish a room from a prompt (the LLM picks from the library, the pieces are placed against the walls clear of the doors), ⤓ .glb export, and 🎬 every camera -> StoryBoard scenes with their shots as first frames + a shot list. *Where:* 🏠 House. *Since:* 2.529.0
- **🔍 Find anything (Ctrl+K)** — a command palette over every docker, floating window, menu / statusbar button, Settings field, workspace, Generate mode, style, guide section and shortcut key; Enter shows / opens / runs it, and the guide opens in a 📖 Help window. *Where:* Ctrl+K or 🔍 in the menu bar. *Since:* 2.530.0
- **Every model file found where ComfyUI lists it** — text encoders, VAEs, LoRAs and ControlNets in another subfolder are used under ComfyUI's name; a file in no folder at all is named with the model catalog entry that downloads it. *Where:* every job; the 🩺 Style doctor. *Since:* 2.531.0
- **Tests that tick themselves** — anything on the 🧪 test list the app sees working is ticked and kept (auto ✓), even after a restart. *Where:* Settings -> General -> 🧪 Testing. *Since:* 2.532.0
- **▁ ⛶ ✕ docker title bars** — minimize a floating docker to its title bar, maximize it to the whole window and back, close it. *Where:* every floating docker. *Since:* 2.532.0
- **⬚ Select, turn and size in the House builder** — handles on the selected piece, box and Shift+click selection, group move / turn / delete. *Where:* 🏠 House. *Since:* 2.532.0
- **📷 Walk a camera through the house** — drag it on the plan with the 3D view looking through it; arrows turn and tilt it, Shift / Alt raise and lower it. *Where:* 🏠 House. *Since:* 2.532.0
- **🧪 Test mode** — suggests the next test where you are (the image editor: blur, brush, eraser …), asks 'Did it work?' with a suggestions box when the app sees a test work, keeps your answers and suggestions in the log; off = nothing ticks or pops up. *Where:* Settings -> General; the 🧪 Testing docker. *Since:* 2.534.0
- **New renders join the open preview** — a picture that finishes while the preview is open joins its strip; ✨ N new jumps to it. *Where:* the picture / video preview. *Since:* 2.534.0
- **Edit image mode shows only edit styles** — with the image editor open, the image style dropdown lists only styles that can edit a picture, and puts your choice back when it closes. *Where:* the prompt docker. *Since:* 2.502.0

### ControlNet and face fix

- **ControlNet** — renders a first picture, turns it into a control image (lineart, depth, pose) and renders the final with a second model. *Where:* Basic Settings
- **ControlNet chain styles** — a two-stage style saved by name. *Where:* Settings > ControlNet. *Since:* 2.97.0
- **Face fix** — re-draws each face of the final picture; an add-on since 2.593.0 (Settings ▸ General switches it on, its models download by themselves). *Where:* Basic Settings
- **Add-ons in the studio** — Face fix and ControlNet switched on or off in Settings ▸ General: off = hidden and never used; on = shown, and whatever they miss (node packs, models) downloads into the right ComfyUI folder by itself - also at every start; their Add-ons cards list every download link. *Where:* Settings ▸ General / Settings ▸ Add-ons. *Since:* 2.593.0

### Pictures onto the image editor

- **Generated pictures onto the canvas** — with the image editor open, Generate makes pictures and each lands as a new layer on the document in front. *Where:* the prompt docker. *Since:* 2.431.0
- **3D models from pictures** — every picture in the Gallery and Assets can become a 3D model (Hunyuan3D 2.1 or TRELLIS.2). *Where:* the 3D button on each picture. *Since:* 2.404.0
- **🧊 Convert to 3D (right-click)** — right-click a picture in the Gallery, Assets or References, or the image editor's canvas (the whole picture or the picked layer, also Layer ▸ Convert Layer to 3D), pick Hunyuan3D 2.1 or TRELLIS.2 and where the model goes: the image editor (a 3D layer you can orbit, render and generate from), the SolidCraft docker, or just the project's 3D models. *Where:* right-click a picture. *Since:* 2.594.0

## Music, voices and sound

Songs, stems, voices and the words in them.

### Music

- **Songs from lyrics and a style** — MiniMax Music3 or YuE2, with up to four songs per press. *Where:* the Music docker. *Since:* 2.90.0
- **Music styles** — a reusable caption (genre, BPM, key, mood, voice) with its workflow and settings. *Where:* Settings > Music
- **Covers and sheet music** — made in the Music docker. *Where:* the Music docker
- **Songs from the chat** — the chat writes lyrics that fit the chosen music style and sends them to the Music docker. *Where:* the prompt chat. *Since:* 2.92.0
- **Lyrics files** — every song keeps its lyrics as a text file in the project. *Where:* the project's lyrics folder

### Stems

- **Split a song** — vocals, drums, bass and other. *Where:* the Stems docker

### Voices and speech

- **Voice cloning** — clone a voice from a short clip or a waveform region. *Where:* the Voice / Stems docker
- **▶ Play in the voice clone's waveform** — plays the selection, or the whole clip when nothing is selected; ■ Stop, a playhead on the wave, a click clears the selection. *Where:* Settings > Audio > voice clone. *Since:* 2.601.0
- **Text to speech** — speak a line in a cloned voice; OpenAudio or OmniVoice (600+ languages, voice design). *Where:* Settings > Audio. *Since:* 2.102.0
- **Ming-3.0 TTS** — a second speech engine (inclusionAI, 0.5B, 44.1 kHz): cloned voices from a clip and its transcript, and designed voices. Installed from Settings ▸ Add-ons. *Where:* Settings > Audio > Speech engine. *Since:* 2.594.0
- **Speech from the prompt** — Generate with the speech mode. *Where:* the Generate dropdown

### Transcription and lyrics

- **Speech to text** — transcribe speech or extract timed lyrics from any sound or video, saved as .txt, .srt and .lrc. *Where:* the asset tray. *Since:* 2.38.0
- **Local transcription** — faster-whisper runs on this computer and each file is transcribed once. *Where:* Settings > Audio
- **Bark 3.0 speech-to-text** — Underdog's Bark 3.0 (163 MB, English only) for plain transcripts, voice clone transcripts, the phone remote and the 🎙 voice chat; lyrics, captions and other timed work stay on faster-whisper. Installed from Settings ▸ Add-ons. *Where:* Settings > Audio > Speech-to-text engine. *Since:* 2.594.0
- **WeVisOne-VL vision model** — Tencent's WeVisOne-VL (built on Qwen3-VL) as the prompt docker's vision model: it reads text in pictures, counts and finds things, and describes them for the LLM. Pick 4B or 2B in a dropdown; it downloads into your vision models folder. *Where:* Settings > Add-ons > WeVisOne-VL. *Since:* 2.595.0
- **⟳ Update llama.cpp** — see which llama.cpp build is installed and whether a newer one is out, and update it in place (the LLM and vision servers stop first; models and settings stay); the progress shows right there. *Where:* Settings > LLM. *Since:* 2.596.0
- **MP4 · Social media export** — a file Facebook, Instagram and TikTok take as it is: H.264 High 8-bit, AAC 48 kHz stereo, a steady frame rate, faststart, 1080 on the short side at most, no timecode track; checked after the encode (each point ok or not, plus a note when a 9:16 is longer than 90 s). The social pack makes 9:16 Reels, the 4:5 feed, 1:1 and 16:9 at once. *Where:* the timeline's 📤 Export. *Since:* 2.597.0
- **📱 Social media in Basic Settings' Format** — Reels / Stories 9:16, Facebook feed 4:5, Square 1:1, Landscape 16:9 or the render's own shape: Aspect follows, and the finished MP4 is made ready for Facebook / Instagram / TikTok (the Export preset's settings, checked) before it lands in the gallery. *Where:* Basic Settings > Format (and the music video's Format). *Since:* 2.600.0
- **Seed: 🎲 Random / 📌 Fixed** — one toggle beside the seed: Random = a new seed every render, Fixed = the number beside it every time (typing a number or ♻ the last seed used makes it Fixed). In Basic Settings (video and image) and in every style (image, video, music) - a style can always render with its own seed. *Where:* Basic Settings, Settings > Image / Video / Music styles. *Since:* 2.598.0
- **Resetting Project lock screen** — while a project resets, a cover over the whole window says "Resetting Project..." with a spinning ring, running dots, what is happening now and the seconds; nothing behind it can be clicked, and it stays through the reload until the empty project is open ("✓ Project reset"). *Where:* ↺ Reset project. *Since:* 2.599.0
- **The Model manager finds what ComfyUI has** — it asks the running ComfyUI where its model folders are and what its dropdowns hold, so models and LoRAs show even when they are not under the ComfyUI folder set in Settings (the Desktop app's own folder, a yaml on ComfyUI's command line). *Where:* 🧩 Models. *Since:* 2.598.0
- **Buttons show what they are doing** — Install, Update, Start (then Loading the model), Stop, Rescan, Scan folder and Save turn into a spinning "…ing" with the seconds, then ✓ or ✗ with the reason. *Where:* Settings > LLM and Save. *Since:* 2.596.0

### Karaoke

- **Karaoke overlays** — a transparent lyrics video with a bouncing ball and a line that changes colour as it is sung. *Where:* the StoryBoard's Karaoke button. *Since:* 2.373.0
- **Karaoke for any song** — pick a sound clip or asset, the whole song or the ruler selection. *Where:* the timeline's Karaoke button. *Since:* 2.380.0
- **Karaoke style** — font, colours, outline, shadow, background band and the ball. *Where:* the StoryBoard and Timeline settings
- **Edit lyrics** — correct the words speech-to-text heard, or paste the real lyrics. *Where:* the Karaoke docker. *Since:* 2.408.0
- **Words and timing** — every word with its start and end, playable and correctable; corrections are kept for the song. *Where:* the Karaoke docker. *Since:* 2.408.0
- **Word nudges** — move a word, or it and every word after it, earlier or later by a small or larger nudge. *Where:* Words and timing. *Since:* 2.433.0
- **The line under the marker** — the line being sung is lit and the word being sung brighter. *Where:* Words and timing. *Since:* 2.433.0
- **Karaoke docker** — docks beside the preview canvas so the song plays while you correct it; show the corrected words on the canvas. *Where:* the timeline. *Since:* 2.410.0

## The timeline

A full video editor: a preview canvas with layers, editing tools, colour, sound, captions, AI and 3D.

### The preview canvas

- **Preview canvas** — the canvas with a toolbar on the left and a Layers panel on the right. *Where:* the timeline docker. *Since:* 2.377.0
- **Drop to add** — drop videos, pictures or sounds on the canvas; each lands on a new layer at the position marker. *Where:* the preview canvas
- **Move tool** — select, move, scale by a corner and rotate by the top handle; Shift for 15-degree steps or one axis. *Where:* key V
- **Text tool** — click to add a text layer with font, size, colour, bold, italic, outline, shadow and alignment. *Where:* key T
- **Every font on this computer** — each font list has the usual fonts under Common and every installed font under This computer (N); a font only in the app's fonts folder loads from its file. *Where:* the image editor's and the timeline's font lists, captions, karaoke style. *Since:* 2.607.0
- **Font previews in the font lists** — each font's name is written in that font (the search list too); the closed list shows the picked one in itself. *Where:* every font list. *Since:* 2.608.0
- **Rasterize Text from the right-click menu** — a text layer (image editor) or a timeline text becomes a picture; undo brings the text back. *Where:* right-click the text. *Since:* 2.604.0
- **Skew that keeps the far side** — the side handles slant from the opposite side (Alt: round the centre); text skews and stays text. *Where:* the image editor's Move tool, double-click for the rotate / skew handles. *Since:* 2.604.0
- **💾 Save to Images in any format** — the visible layers kept as a temp copy, flattened (JPEG / BMP on white) and saved in the format picked beside 💾 into Images and the Gallery. *Where:* the image editor's menu bar (Ctrl+S). *Since:* 2.604.0
- **Typing that fits, editing at the click** — the frame round the text being typed hugs the letters and grows with each key; over a text the pointer is the text I-beam (elsewhere the new-text cursor); a click edits from between the letters where you clicked, also on wrapped paragraph text. *Where:* the image editor's Type tool (T). *Since:* 2.602.0
- **Hand and Zoom** — pan, zoom and fit the picture. *Where:* keys H, Z
- **Fill a selection** — draw a box or paint a mask, then generate a picture or video that blends into it. *Where:* keys M and B, and Fill in the Layers panel. *Since:* 2.380.0
- **Play with sound** — every layer plays together with sound; loop the ruler selection. *Where:* under the canvas
- **Compile matches the canvas** — moved, scaled and rotated layers and text are compiled exactly where the canvas shows them. *Where:* Compile
- **Hover highlight** — with the Move tool the clip under the pointer is outlined in blue, the picked one in orange. *Where:* the preview canvas. *Since:* 2.470.0

### Layers, clips and the position marker

- **Layers** — V1 as the base picture plus video, picture, sound, text, 3D and Karaoke layers. *Where:* the timeline
- **Layer colours** — each layer has its own colour; the selected one is outlined. *Where:* the timeline. *Since:* 2.383.0
- **Rename layers** — double-click a name, press F2, or use the Name box. *Where:* the Layers list and tracks. *Since:* 2.382.1
- **Drag the marker** — move around at will; double-click a time to jump there and play. *Where:* the ruler. *Since:* 2.383.0
- **Ruler selection** — select a stretch, keep or cut it, trim the head or tail of a clip. *Where:* the ruler
- **Nudge clips** — arrow keys move a clip by frames, Shift by a second. *Where:* Timeline settings. *Since:* 2.376.0
- **Named timelines** — a project holds several timelines; switch, save and save as. *Where:* the timeline toolbar. *Since:* 2.107.0
- **Transitions** — 59 transitions, drawn as their shape on entry and exit. *Where:* each layer. *Since:* 2.415.0

### Keyframes

- **Keyframes** — position, scale, rotation, opacity and text colour, tweened on the canvas and in the compile. *Where:* the Key button in the Layers panel. *Since:* 2.379.0
- **Eases** — linear, ease in, ease out, ease in and out, or hold. *Where:* the keyframe menu
- **Graph Editor** — value and speed graphs with draggable keyframes and Bézier handles; Easy Ease, linear and hold in a click. *Where:* the 📈 Graph button in the Properties. *Since:* 2.489.0
- **Motion blur, Posterize Time, Echo** — blur a layer's movement (shutter angle, samples), hold it at a lower frame rate, or trail copies of it behind it. *Where:* ⏱ Time in a layer's Properties. *Since:* 2.500.0
- **Time remapping on a curve** — choose which source second shows at each moment of a video clip: forward, backwards, frozen, faster or slower, with keys on a curve, ◇ Key and ❄ Freeze at the playhead. *Where:* ⏱ Time remap in a video clip's 🎬 Speed. *Since:* 2.501.0
- **Generator layers: Fractal Noise and Gradient Ramp** — a click of the 🌫 tool makes animated fractal noise over the frame, a drag a linear or radial ramp; every setting keyable. *Where:* the 🌫 tool on the timeline canvas, 🌫 Generator in the layer's Properties. *Since:* 2.505.0
- **Turbulent displace and displacement maps** — push any layer's pixels with moving noise or with another layer's picture; the compile matches, video layers included. *Where:* 〰 Distort in a layer's Properties. *Since:* 2.505.0
- **Particles** — a Shift+click of the 🌫 tool makes a particle emitter (point, line or box) with speed, direction, spread, gravity, wind and five particle shapes; every setting keyable, and the same picture every time it is drawn. *Where:* the 🌫 tool on the timeline canvas, 🌫 Generator (Particles) in the layer's Properties. *Since:* 2.506.0
- **Light rays** — the bright parts of any layer streak away from a point, past its edges; video layers are baked whole by the page for the compile. *Where:* ☀ Light rays in a layer's Properties. *Since:* 2.506.0
- **Puppet pins** — pin a layer and drag the pins to bend it like a puppet; the other pins hold, and the pins can be keyed so the layer moves over time. *Where:* the 📌 Puppet tool (Shift+W) on the timeline canvas, 📌 Warp in the layer's Properties. *Since:* 2.507.0
- **Mesh warp** — a grid of up to 8 × 8 points over a layer, dragged to bend the picture along smooth curves; keyable, and the compile matches, video layers included. *Where:* ⌗ Mesh warp in 📌 Warp in a layer's Properties. *Since:* 2.507.0
- **Audio → keys** — key any property (opacity, scale, position, turn, generator numbers) to a sound's loudness, bass, mids or treble, from a quiet value to a loud one, thinned to the keys that matter. *Where:* ♪ Audio → keys in a layer's Properties. *Since:* 2.508.0
- **Audio waveform and spectrum layers** — layers that draw the sound: its wave around the playhead (wave, line, bars) or its frequencies (bars, line, circle); every setting keyable; one clip or all sound. *Where:* Alt+click / Alt+Shift+click with the 🌫 tool on the timeline canvas. *Since:* 2.508.0
- **audio() in expressions** — the mix's loudness, bass, mids or treble (0..1) at any moment, for expressions on any property. *Where:* ƒx on a property, its presets. *Since:* 2.508.0
- **Motion sketch** — press and move on the canvas while the timeline plays: the layer follows the pointer and the path becomes position keys, thinned to the ones that matter. *Where:* the ✍ tool (Shift+K) on the timeline canvas, 〰 Motion in a layer's Properties. *Since:* 2.509.0
- **The wiggler** — random movement added to any property as keys (how often, how far, smooth or jagged, position x / y apart, a seed), riding on the move already there. *Where:* ≈ Wiggler in 〰 Motion in a layer's Properties. *Since:* 2.509.0
- **The smoother** — a property's keys averaged and thinned within a tolerance: fewer keys, the same shape. *Where:* ⌇ Smoother in 〰 Motion in a layer's Properties. *Since:* 2.509.0
- **2D layers in 3D** — any layer becomes a card with depth and an x / y turn, seen in perspective by a keyable 3D camera (position, aim, zoom) with an orbit / dolly / track tool. *Where:* 🧊 3D in a layer's Properties, the 🧊 tool (Shift+O). *Since:* 2.510.0
- **Depth of field and light shadows for 3D cards** — cards blur by their distance from the focus, and a light throws the cards' shapes as shadows onto the cards behind them. *Where:* 🎥 3D camera in a 3D layer's Properties. *Since:* 2.510.0
- **Variable mask feather** — each mask point can have its own feather (Shift+drag it with the Mask Pen); the edge glides between them, animated paths too. *Where:* ✒ Mask Pen on the timeline canvas, ✒ Masks in the Properties. *Since:* 2.511.0
- **Data-driven animation** — import CSV or JSON as data sets with a current row; {{set.column}} in texts, data() in expressions, and a column keyed onto any property a row at a time. *Where:* 📋 Data & fields in a layer's Properties. *Since:* 2.511.0
- **Exposed template fields** — label a layer's colour, opacity, position, scale or turn as a field; edit every field in one list, and templates offer them when dropped in. *Where:* 📋 Template fields in a layer's Properties, 🧩 Templates. *Since:* 2.511.0
- **Lottie (JSON) export** — the picture and text layers as a Lottie animation for the web and apps: moves, scales, turns and fades as real animated layers with their eases, effect layers as frames; checked against lottie-web. *Where:* 📤 Export → ⤓ Lottie (JSON). *Since:* 2.512.0
- **Load UE project** — pick an Unreal project's folder and bitGen puts the bitGen Bridge plugin in (or updates it), switches on the plugins it needs and restarts Unreal with the project. *Where:* 🎮 in the menu bar. *Since:* 2.513.0
- **The timeline's frame size** — width × height, size presets (4K to vertical and square) and a kept aspect ratio for the canvas and the compile; V1 is fitted inside and centred. *Where:* the bar at the top of the Timeline docker. *Since:* 2.513.0
- **Cut out a subject through a shot** — click the subject (or box it) and it is followed through the clip (SAM 2, the AI matte or built in), refine edge, a see-through video layer. *Where:* 🧍 Cut out in a video clip's Properties. *Since:* 2.515.0
- **Content-aware fill for video** — take a cut-out subject or masked area out of every frame, filled from the frames round it (+ a reference frame). *Where:* 🩹 Remove in a video clip's Properties. *Since:* 2.515.0
- **3D camera tracker** — solve the camera and the scene's points, pick points and place a layer flat, standing or facing the camera; the 3D camera follows the solve (with roll). *Where:* 📷 3D camera track in a video clip's Properties. *Since:* 2.515.0
- **Keyframes on any setting** — a ◇ beside every colour, effect, mask, text and time setting keys it at the playhead (then changing it keys it); the Graph Editor shows them and the compile matches. *Where:* ◇ in a clip's Properties and the 🎨 Colour dialog. *Since:* 2.516.0
- **Edit theme mode: resize, move, hide, rename** — drag handles to resize an element, drag it to move it, hide it or change its text; every change is kept in themes/<name>.tmp, and leaving edit mode offers Save theme, Save theme as…, Reset theme, Not now or Cancel. *Where:* 🖌 in the top bar. *Since:* 2.514.0
- **Edit theme mode: every button and its words** — double-click any words (buttons, docker titles, tabs, labels, headings, hints) to change them in place; rename a dropdown's options; change placeholders and tooltips; the floating tool panels are edited like the dockers; Alt+click opens sections / tabs / menus without leaving the mode. *Where:* 🖌 in the top bar. *Since:* 2.623.0
- **Hidden in Expert mode** — a theme can hide an element only while Expert mode is on; Basic mode still shows it. *Where:* edit theme mode > the Style panel > Hide. *Since:* 2.544.0
- **Theme edit mode for dialogs** — Ctrl+Shift+Alt+E styles an open dialog (Settings …) too; Ctrl+S saves the theme and leaves. *Where:* anywhere. *Since:* 2.515.0
- **Folding dockers** — the side dockers fold to a thin title strip; the image editor's docker groups fold to their tabs and close with ✕; View ▸ Dockers shows or hides each one. *Where:* ▾ in a docker's title bar; the image editor's View menu. *Since:* 2.514.0
- **Motion tracking** — follow a point, two points (scale and rotation), four corners or a flat surface (planar) through a clip to a fraction of a pixel, then apply it to a layer's position or pin a layer into it. *Where:* 🎯 Track in a video clip's Properties. *Since:* 2.499.0
- **Corner pin** — draw a layer into four corners, tracked or dragged by hand; the compile matches the canvas. *Where:* ▢ Corner pin in a layer's Properties. *Since:* 2.499.0
- **Bézier masks** — several masks per layer drawn with a pen (corners and curves), with add, subtract, intersect and difference, feather, expansion, opacity, invert and an animated path; pictures, text, shapes and video. *Where:* the ✒ Mask Pen (Shift+M) and ✒ Masks in a layer's Properties. *Since:* 2.498.0
- **Expressions** — a small formula on a layer property (position, scale, rotation, opacity, anchor, shape and text animator numbers): wiggle, loops, delays, ranges, random, links to other layers; checked as you type; the compile follows it. *Where:* ƒx Expressions in a layer's Properties. *Since:* 2.497.0
- **Roving keyframes** — a position key's time follows the motion path for an even speed between its neighbours. *Where:* Rove in the Graph Editor. *Since:* 2.496.0
- **Easy Ease** — ease a keyframe in and out, or one side only. *Where:* the Properties, F9 (Shift+F9 in, Ctrl+Shift+F9 out). *Since:* 2.489.0
- **Anchor point** — what position places and scale and rotation turn about; keyframable; the layer stays put when you move it. *Where:* ⊕ Anchor in the Properties. *Since:* 2.489.0
- **Curved motion paths** — the position path drawn on the canvas with Bézier handles to bend it; Smooth path in one click. *Where:* the canvas, ↝ Smooth path. *Since:* 2.489.0
- **Parenting** — a picture, text, null or (since 2.495.0) video layer follows another layer's position, rotation and scale; it stays put when the parent is chosen or cleared, and the compile follows it. *Where:* ⛓ Parent in the Properties. *Since:* 2.490.0
- **Null objects** — empty control layers to key and parent others to; never compiled. *Where:* ＋ Null in the Properties. *Since:* 2.490.0
- **Blend modes** — Multiply, Screen, Overlay, Darken, Lighten, Color Dodge and Burn, Hard and Soft Light, Difference, Exclusion, Add and (since 2.495.0) Hue, Saturation, Color and Luminosity per layer, on the canvas and in the compile. *Where:* ◐ Blend in the Properties. *Since:* 2.491.0
- **Track mattes** — show a layer only where the layer above it is (alpha or luma, or inverted); video inside text and the like. *Where:* ▣ Matte in the Properties. *Since:* 2.491.0
- **Shape layers** — rectangles, ellipses, stars and polygons drawn with the Shape tool, with a colour or gradient fill and a stroke. *Where:* ◆ in the canvas toolbar (Q). *Since:* 2.492.0
- **Shape operators** — Trim Paths, Repeater, Offset Paths, Pucker & Bloat, Twist, Zig Zag, Wiggle Paths and Round Corners, every number keyable. *Where:* a shape layer's Properties. *Since:* 2.492.0
- **Freehand shapes** — draw a closed shape or an open line by hand, smoothed; Alt adds it to the picked shape layer as another path. *Where:* the ✎ Freehand tool (Shift+Q). *Since:* 2.496.0
- **Merge Paths** — several paths in one shape layer combined by add, subtract, intersect or exclude, holes included; the operators after it work on the merged outline. *Where:* ⧉ Paths and ⊕ Merge Paths in a shape layer's Properties. *Since:* 2.496.0
- **Text animators** — move, turn, scale, fade, space out, blur or recolour the letters, words or lines a range selects; Typewriter, Fade up, Pop in, Slide in, Wave and Blur in presets; every number keyable. *Where:* ✨ Text Animators in a text layer's Properties. *Since:* 2.493.0
- **Text on a path** — the letters run along an arc, circle, wave or a shape layer's outline, turned to it; the start is keyable. *Where:* 〰 On a path in a text layer's Properties. *Since:* 2.496.0
- **Edit a keyframe** — click a diamond on a clip for its opacity, volume, place, scale, rotation, colour and ease. *Where:* the timeline
- **Drag and delete keyframes** — drag along the clip; right-click, Alt-click or Delete removes one. *Where:* the timeline. *Since:* 2.385.0
- **Volume keyframes** — on sound clips too. *Where:* sound clips
- **Effect keyframes** — blur, sharpen, glow, vignette, grain and crop move from key to key. *Where:* a clip's Effects. *Since:* 2.412.0

### Edit tools and keys

- **Ripple, Roll, Slip and Slide** — trim and move everything after, move a cut, show other frames, or slide between neighbours. *Where:* keys V, B, N, Y, U. *Since:* 2.407.0
- **Split** — split at the position marker. *Where:* Ctrl+K. *Since:* 2.410.0
- **Track targets** — split every targeted layer at once. *Where:* the target in each layer header. *Since:* 2.412.0
- **J / K / L shuttle** — play backwards or forwards at 2x, 4x, 8x; step a frame. *Where:* the timeline docker. *Since:* 2.411.0
- **Edit points and ends** — previous or next edit point, the start or the end. *Where:* arrow keys, Home, End. *Since:* 2.410.0
- **Edits on reversed and ramped clips** — the edit tools and split are frame-exact on retimed clips. *Where:* the timeline. *Since:* 2.413.0

### Markers and timecode

- **Markers** — named, coloured flags with comments; next and previous marker. *Where:* key M. *Since:* 2.410.0
- **Marker ranges and clip markers** — markers with a length, and markers that stay on a clip's frame. *Where:* the marker editor, Ctrl+Shift+M. *Since:* 2.412.0
- **Timecode** — HH:MM:SS:FF with a start and frame rate; drop-frame at 29.97 and 59.94. *Where:* beside the position. *Since:* 2.407.0

### Speed

- **Speed** — 10 to 1000 %, with the clip's length following. *Where:* a clip's Speed fold. *Since:* 2.406.0
- **Reverse and ramps** — play backwards or ramp the speed along the clip. *Where:* a clip's Speed fold. *Since:* 2.406.0
- **Slowed frames** — repeat, blend or optical flow. *Where:* a clip's Speed fold. *Since:* 2.406.0
- **Reversed sound on the canvas** — a reversed or ramped clip's sound is rendered once and heard in step. *Where:* the canvas. *Since:* 2.417.0

### Colour

- **Looks and sliders** — teal and orange, warm film, cool night and more; exposure, contrast, saturation, temperature, tint and hue. *Where:* a clip's Colour fold. *Since:* 2.406.0
- **LUTs** — import any 3D .cube LUT and blend it. *Where:* a clip's Colour fold. *Since:* 2.406.0
- **Colour wheels and curves** — lift, gamma and gain wheels; master and RGB curves. *Where:* the Colour dialog. *Since:* 2.407.0
- **HSL secondaries** — up to six hue ranges shifted, saturated or lightened. *Where:* the Colour dialog. *Since:* 2.407.0
- **Hue curves** — hue vs hue and hue vs saturation. *Where:* the Colour dialog. *Since:* 2.412.0
- **Scopes** — waveform, RGB parade, vectorscope and histogram. *Where:* the Colour dialog. *Since:* 2.407.0
- **Colour match** — set a clip's curves to match another clip. *Where:* the Colour dialog. *Since:* 2.415.0
- **What you see is what you get** — the grade is baked into one table the canvas and compile share. *Where:* the canvas
- **HDR clips tone-mapped** — a phone's HDR video is tone-mapped into the movie. *Where:* the compile. *Since:* 2.417.0

### Effects and adjustment layers

- **Effects** — blur, sharpen, glow, vignette, grain, crop, green / blue screen key and stabilise. *Where:* a clip's Effects. *Since:* 2.409.0
- **Distort effects** — lens, mirror and warp (wave, twirl). *Where:* a clip's Effects. *Since:* 2.415.0
- **Stabilise modes** — smooth or locked, with a steady preview. *Where:* a clip's Effects. *Since:* 2.413.0
- **Adjustment layers** — colour and effects that work on everything under them. *Where:* the timeline toolbar. *Since:* 2.409.0

### Masks and tracking

- **Masks (power windows)** — an ellipse or box with feather and invert limits the grade and effects. *Where:* the Colour panel. *Since:* 2.416.0
- **Tracking** — the mask follows the thing to the clip's end. *Where:* the Colour panel. *Since:* 2.416.0

### Sound and mixing

- **Clean-up** — voice clarity, denoise and gain, with a before / after preview. *Where:* a clip's Sound fold. *Since:* 2.406.0
- **EQ, multiband and reverb** — on any clip's sound. *Where:* a clip's Sound fold. *Since:* 2.412.0
- **J / L cuts** — a clip's sound starts early or runs on late. *Where:* a clip's Sound fold. *Since:* 2.407.0
- **Linked sound** — a video's sound as its own linked clip; unlink or bring it back. *Where:* a clip's Properties. *Since:* 2.412.0
- **Mix dialog** — voice, music and sfx roles, ducking and loudness to a target. *Where:* the timeline's Mix button. *Since:* 2.406.0
- **Track mixer** — a fader, pan, mute, solo and live level meter per track and for the master. *Where:* the timeline menu bar. *Since:* 2.415.0
- **Waveforms** — every sound clip shows its waveform. *Where:* sound layers. *Since:* 2.64.0

### Captions and transcripts

- **Captions from speech** — everything that speaks is transcribed locally and placed where each clip sits. *Where:* the timeline's Captions button. *Since:* 2.406.0
- **Edit and style captions** — times, words, font, size, colour, outline or box, position. *Where:* the Captions dialog. *Since:* 2.406.0
- **Burn in or .srt** — burned into the movie and / or an .srt beside it. *Where:* the Captions dialog. *Since:* 2.406.0
- **Edit by transcript** — choose words, cut them or keep only them; remove pauses and filler words. *Where:* the timeline's Transcript button. *Since:* 2.408.0
- **Transcript scope** — this clip, its layer or the whole sequence. *Where:* the Transcript dialog. *Since:* 2.414.0
- **Scene cuts** — split a clip where its shots change, or drop markers there. *Where:* the Transcript dialog. *Since:* 2.408.0

### Multi-camera, nesting and proxies

- **Multi-camera** — sync angles by sound and cut live with keys 1 to 9; flatten into ordinary clips. *Where:* the timeline. *Since:* 2.416.0
- **Nested sequences** — another timeline compiled into one clip, re-rendered when it changes. *Where:* the timeline menu bar. *Since:* 2.414.0
- **Proxies** — small copies of heavy footage for playback; the movie uses the originals. *Where:* the timeline. *Since:* 2.416.0

### Playback

- **Render bar** — shows which stretches play live, may drop frames, are too heavy, or are rendered. *Where:* under the ruler. *Since:* 2.418.0
- **Render previews** — compile once and play the exact movie at full speed over rendered stretches. *Where:* the Render button. *Since:* 2.418.0
- **Late-frame counter and playback resolution** — full, half or quarter size while playing. *Where:* beside play. *Since:* 2.418.0
- **GPU compositor** — layers composited on the graphics card while playing. *Where:* the GPU switch. *Since:* 2.420.0

### AI in the timeline

- **New take** — render a clip again in its own slot and switch between takes. *Where:* the AI menu. *Since:* 2.420.0
- **Extend** — more seconds continuing from a clip's last frame. *Where:* the AI menu. *Since:* 2.420.0
- **B-roll** — fill an empty stretch of V1, or a cutaway over a range. *Where:* the AI menu. *Since:* 2.420.0
- **Cut to the beat** — find a song's beats, then drop markers or cut a clip on them. *Where:* the AI menu. *Since:* 2.420.0

### Path layers

- **Path layers** — draw a path and a subject (animal, person, vehicle) follows it, with size and pace. *Where:* the timeline bar's Path layer button. *Since:* 2.387.0
- **In place or along the path** — a green-screen clip moved by keyframes, or Wan ATI making it travel itself. *Where:* the path layer's panel. *Since:* 2.387.0
- **Cut out** — an AI matte or a chroma key; every path layer is see-through. *Where:* the path layer's panel. *Since:* 2.387.0

### The camera path

- **Camera panel** — presets, pan, tilt, roll, height, dolly and lens keys, with camera, top and side views. *Where:* the timeline bar's Camera. *Since:* 2.399.0
- **The camera tool** — drag on the canvas to pan, tilt, roll, change height and dolly. *Where:* Shift+C. *Since:* 2.399.0
- **Use in Generate** — each video model is told the move it can follow. *Where:* the Camera panel. *Since:* 2.399.0
- **Exact path guide** — a picture with depth flown along the path as a guide video. *Where:* the Camera panel. *Since:* 2.399.0

### 3D layers on the timeline

- **3D text and models** — extruded 3D text or FBX, OBJ, GLB and glTF models, moved and keyframed like any layer. *Where:* the 3D button under T. *Since:* 2.382.0
- **3D widgets** — move, rotate and scale in 3D with G, R and S. *Where:* the Move tool. *Since:* 2.385.0
- **Materials and lights** — material presets or your own, studio lights and your own point, spot, sun, ambient and sky lights. *Where:* the 3D layer's Properties. *Since:* 2.385.0
- **The 3D toolbar** — widget, snap, views, spin, reset, material, lights, key and bake. *Where:* along the top of the canvas. *Since:* 2.386.0
- **Baked for the compile** — a 3D layer is baked into a see-through video automatically. *Where:* Compile
- **Render with Blender** — a 3D layer rendered by Blender for the compile. *Where:* the 3D layer's Properties. *Since:* 2.385.0

### Rulers, guidelines and grids

- **Rulers and guidelines** — rulers in picture pixels; drag guidelines out, move them or type their place. *Where:* the timeline menu bar. *Since:* 2.446.0
- **Snapping** — moved layers snap to guidelines, the picture's edges and centre, and the grid. *Where:* the preview canvas. *Since:* 2.446.0
- **Grid** — a grid over the preview canvas with its own settings. *Where:* the timeline menu bar. *Since:* 2.445.0
- **Grids and Guides settings** — spacing, major lines, lines or dots, colours and snap distance. *Where:* Timeline settings. *Since:* 2.445.0

### Text and templates

- **Text effect presets** — layered 3D text looks drawn live as you type; import your own from a PSD. *Where:* a text layer's Properties. *Since:* 2.411.0
- **Presets on animated, on-a-path and 3D text** — a text with a preset keeps it with ✨ Text Animators and 〰 On a path; 3D text takes a preset as its front face (sides in its colour). *Where:* a text's Properties, a 3D text's Properties. *Since:* 2.607.0
- **New text with your preset** — the T tool's new text starts with the preset last picked; nothing selected = Properties ▸ New text ▸ Preset. *Where:* the timeline. *Since:* 2.607.0
- **🧬 Morph** — one character turns into another between two layers: write both characters, pick the two layers; the prompt is written, the first / last frames are taken, the video model renders it, it lands on a 🧬 Morph layer between them and layer 2 moves to start after it. *Where:* the timeline's layers panel ▸ 🧬 Morph tab. *Since:* 2.610.0
- **▯ Frame: click a frame, Del removes it** — a timeline tool that selects single frames on one layer (click, drag for several, Shift+click, ← / →); Del / ⌫ cuts them out of that layer and closes the gap, ↶ puts them back. *Where:* the timeline's menu bar ▸ ▯ (or F over the layers). *Since:* 2.611.0
- **A cut clip stays one clip** — ✂ Cut / Del on frames through a clip joins the parts before and after into one continuous clip (a video / sound made into one "-join" file, frame-exact; a picture just shorter); one ↶. The preview loads the next clip a second early, so a cut never flashes black. *Where:* the timeline ▸ ✂ Cut (ripple on). *Since:* 2.612.0
- **▼ Ranges marked while it plays** — tap Ctrl while the preview plays for a range's start and again for its end, as many as you like on the highlighted layer, each its own colour; drag a ▼ to move it (the preview shows that frame). *Where:* the timeline (Ctrl), ▼ in the time ruler. *Since:* 2.613.0
- **Pick ranges, ✂ Cut cuts them** — click a ▼ to pick its range, Ctrl / Shift + click for more; ✂ Cut (and ⏩ / ✕) work on the picked ones, all when none is picked. *Where:* the timeline's ruler ▼ + the menu bar's ▼ group. *Since:* 2.614.0
- **Basic Settings per style** — every style keeps the Basic Settings you last used with it (misc/basic_settings.tmp): a style change saves the settings for the style you leave first, then puts back the new style's; the app opens on the last styles with their settings. A video style carries everything but the image set; an image style the image set. *Where:* any style list (the prompt docker, Basic Settings' style card). *Since:* 2.615.0
- **Install with one file** — install_all.bat / install_all.sh / install_all.command: Git and Node.js installed when missing (Windows: Python too), the repository cloned next to it, then the studio starts (the first start installs the rest). *Where:* the repository's root - download just that file. *Since:* 2.616.0
- **Text effects from a zip** — a zip of PSD text effects (a pack) installs every effect in it as a preset in one go, with the fonts it carries; several PSDs can be picked at once too. *Where:* a text layer's Properties / the image editor's Type tool ▸ Presets ▾ ＋ Import PSD text effects or a zip…. *Since:* 2.617.0
- **Hidden / deleted bridge layers close their bridge** — a Blender, 3D (Daz / Blender) or Unreal layer that is hidden or deleted closes its scene / live view in the image editor and the timeline (the Blender process ends, the Unreal View stops, Daz's waiting commands are dropped). *Where:* the image editor's Layers (👁 / delete), the timeline's layers. *Since:* 2.618.0
- **✂ Cut all ranges / ⏩ Speed up ranges** — cut every marked range at once (a clip cut several times stays one clip), or play each 2× - 10× faster to fast-forward a render. *Where:* the timeline's menu bar ▸ ▼ group. *Since:* 2.613.0
- **Hover time + playback speed** — the time under the pointer in a small box over the timeline; the preview plays at 0.125× - 8×. *Where:* the timeline; the speed list under the preview. *Since:* 2.613.0
- **✂ to new layer** — a checkbox that puts the part after a cut or a Ctrl+K split on a new layer right above. *Where:* the timeline's menu bar. *Since:* 2.612.0
- **Text in a shape layer** — a text stretched to fill a shape layer's outline or flowed inside it (Fit), placed on it; follows an animated shape. *Where:* a text's Properties ▸ 🔤 In a shape. *Since:* 2.608.0
- **🅰 Text fill for shape layers** — the shape filled with rows of text (font, size, colour, angle). *Where:* a shape layer's Properties ▸ ◆ Shape. *Since:* 2.608.0
- **Warp presets on any layer** — 16 presets (Arc … Twist, Wedge) as an editable ⌗ mesh you drag with 📌. *Where:* Properties ▸ 📌 Warp ▸ ⌇ Preset. *Since:* 2.608.0
- **Motion graphics templates** — lower third, title card, end card and corner tag, or save your own. *Where:* the timeline menu bar. *Since:* 2.417.0

### Tools and the CAD toolbar on the timeline

- **Tools and Properties docker** — the canvas tools and the selected layer's settings in a docker of their own, docked beside the canvas or floating. *Where:* key 1. *Since:* 2.385.0
- **The timeline's CAD toolbar** — a ribbon over the preview row with Create, 3D, Sketch, Solid and Unreal tabs (see CAD and 3D). *Where:* the timeline. *Since:* 2.470.0
- **Timeline settings** — nudge, song time, karaoke style and grids. *Where:* the settings button at the right of the timeline menu bar. *Since:* 2.376.0

## The image editor

A layered picture editor with selections, retouching, smart objects, type, vector drawing, dimensions, CAD sketches and AI, all running on this computer.

### Layout, documents and panels

- **Menu bar, options bar and tool column** — File, Edit, Image, Layer, Select, Filter, View, Window and Help, each item with its usual shortcut; the options bar shows the current tool's settings. *Where:* the Image editor docker. *Since:* 2.389.0
- **Tool groups** — tools with more in their group cycle with Shift and their key, or open with a right-click or long-press. *Where:* the tool column
- **Command palette** — type part of a command and press Enter. *Where:* Ctrl+K
- **Keyboard shortcuts list** — every key in one list. *Where:* Help > Keyboard Shortcuts
- **Full screen** — the editor fills the space between bitGen's own bars; its status line moves into bitGen's status bar. *Where:* F or the full-screen button. *Since:* 2.393.0
- **Show or hide panels** — Tab hides every panel, Shift+Tab only the panel groups. *Where:* the image editor
- **Documents** — every New or Open is its own document with its own layers, undo, selection, paths, channels and zoom. *Where:* the image editor. *Since:* 2.430.0
- **Tabs and floating windows** — the first document docks as a tab, the next ones float in their own windows; drag between the two. *Where:* the document tabs. *Since:* 2.430.0
- **Close and arrange documents** — Close and Close All ask about unsaved changes; tile, cascade, consolidate to tabs, next and previous document. *Where:* File and Window > Arrange. *Since:* 2.430.0
- **Panel groups** — Color and Swatches; Properties, Adjustments, AI and Control; Layers, Paths, Channels, History, Actions and Comps; plus the Character, Paragraph, Sketch, 3D, Body and Unreal tabs. *Where:* the right column
- **Floating panel groups** — every tab group floats with its float button and docks back into the column. *Where:* each group's tabs. *Since:* 2.438.0
- **The column is a docker** — drop a floating group above or below another (an orange line shows where); the column's width drags from 200 to 640 px. *Where:* the right column. *Since:* 2.454.0
- **Named dockers in the editor** — dock floating groups as tabs in a docker you name. *Where:* Window > New Docker. *Since:* 2.438.0
- **The property bar** — X, Y, W and H of the picked layer with a proportion lock; rectangle corner radii; a vector shape's outline width and line style. *Where:* under the options bar. *Since:* 2.439.0
- **History** — the last 80 steps; click one to go back or forward to it. *Where:* the History panel
- **Editor settings** — AI results, context, feather, megapixels, what Apply does, the look, rulers, panels and the options bar. *Where:* the settings button, or Edit > Preferences (Ctrl+,). *Since:* 2.444.0

### Layers

- **Pixel, fill, text and shape layers** — solid colour or gradient fills, editable text and shapes. *Where:* the Layers panel
- **Adjustment layers** — 16 kinds (Brightness/Contrast, Levels, Curves, Exposure, Vibrance, Hue/Saturation, Color Balance, Black & White, Photo Filter, Channel Mixer, Color Lookup, Gradient Map, Selective Color, Invert, Posterize, Threshold), live in Properties. *Where:* the Adjustments panel
- **Groups** — Ctrl+G groups, Shift+Ctrl+G ungroups; Pass Through lets a group's adjustments reach the layers under it. *Where:* the Layers panel
- **Layer masks** — paint on the mask, Alt-click to view it, Shift-click to disable it, Ctrl-click to load it as a selection; density, feather, invert, apply. *Where:* the Layers panel
- **Clipping** — a layer shows only where the layer below has pixels. *Where:* Alt+Ctrl+G
- **Fill opacity, locks and labels** — fill opacity dims pixels but not styles; lock transparency, pixels, position or all; colour labels from the right-click menu. *Where:* the Layers panel
- **Arrange and merge** — move layers up and down, Merge Down, Merge Visible, Flatten Image, Rasterize. *Where:* the Layer menu
- **Layer comps** — keep the layers' visibility, position and appearance, switch between comps, update one, or go back to the last document state. *Where:* Window > Layer Comps. *Since:* 2.434.0
- **Delete a layer** — Del deletes the current layer (or clears a selection); Shift+Del always deletes the layer. *Where:* the image editor. *Since:* 2.451.0
- **No tool** — Esc puts the tools down (nothing picked); a click picks an object, Shift or Ctrl adds it. *Where:* the image editor, Esc. *Since:* 2.474.0
- **The selection box** — with no tool, drag a dashed box: left to right picks the layers wholly inside it, right to left the ones it touches; Shift adds. *Where:* the canvas with no tool. *Since:* 2.474.0
- **Several layers at once** — Shift-click picks every layer between two, Ctrl-click adds or takes one away; the Move tool moves them together and Del deletes them all. *Where:* the Layers panel. *Since:* 2.474.0
- **Group and delete picked layers** — with several layers picked, Ctrl+G puts them in one group (Ctrl+G on one group ungroups it), and the 🗑 button deletes them all. *Where:* the Layers panel. *Since:* 2.547.0
- **Drop as a layer or a new document** — a picture dropped on an open canvas asks: add it as a layer or open it as a new document. *Where:* the image editor's canvas. *Since:* 2.549.0
- **Generate = a new layer** — in image-edit mode a generated picture always comes in as a new layer, with the style picked in the prompt docker (Krea 2 and every other style are listed for Generate). *Where:* the prompt docker in image-edit mode. *Since:* 2.549.0
- **Seamless fill** — a selection is filled with the prompt docker's style through its own graph (the picture encoded + a noise mask + differential diffusion), so it blends like the Krita AI plugin; Krea 2, Klein and the others can fill now. *Where:* the image editor with a selection, Generate / Refine. *Since:* 2.550.0
- **Transform with skew; Move after Paste** — Ctrl+T (or ⤡ Transform on the Move tool's bar) scales, rotates and skews (Ctrl + an edge); Paste drops the selection so the Move tool moves the pasted layer. *Where:* the image editor. *Since:* 2.550.0
- **Skew from the middle handles** — Free Transform's middle handles skew the layer (a skew cursor), Shift / Alt + a middle handle stretches. *Where:* the image editor, Ctrl+T. *Since:* 2.551.0
- **Fill like the Krita AI plugin** — more context around a selection, the selection pre-filled from its border, a soft mask, a start at 0.9 for models not trained to inpaint. *Where:* the image editor with a selection. *Since:* 2.551.0
- **Fill and Edit from the Krita plugin's own code** — Generate at full strength, a small region rendered bigger, the mask sized by the selection, a blend past the edge with a colour match, Edit in a selection changes only the selection. *Where:* the image editor with a selection. *Since:* 2.552.0
- **Fill with the edit model** — Generate / Remove / New background in a selection through the edit model (the selection painted green + Krita's instruction), so the new part belongs in the scene; ▾ Edit keeps to the selection, or to the layer's own pixels. *Where:* the image editor's ✨ AI panel (👁), the prompt docker. *Since:* 2.553.0
- **Generate fits the selection** — a style that cannot see around a selection makes its picture at the selection's own box, so what it draws is the selection's size. *Where:* the image editor's ✨ AI panel (👁 off), the prompt docker. *Since:* 2.554.0
- **The Krita AI plugin's fill per model family** — SDXL / Pony with the Fooocus inpaint patch, Illustrious / SD 1.5 / FLUX.1 with inpainting ControlNets, Remove with MAT / LaMa first, Krita's context bounds and its Add content / Fill modes. *Where:* the image editor's ✨ AI panel (fill row), the prompt docker; setup lists the pack and models. *Since:* 2.555.0
- **⏳ Pending** — every ✨ run queues without waiting; results wait in a docker inside the editor, ✔ Apply puts one above its layer in that layer's "✨ changes" group, 🗑 Delete drops it. *Where:* the image editor (⏳ Pending in the ✨ AI panel). *Since:* 2.556.0
- **Any floating docker in the panel column** — drag a floating docker (a main docker floated with ⇱, a ▣ docker, Basic Settings, LLM tokens, the prompt docker, ⏳ Pending) by its title onto the image editor's panel column: docked there - fold, move, size or float it again from its bar; kept for the next start and shown / hidden with the editor. *Where:* the image editor's panel column (where Layers is). *Since:* 2.609.0
- **References in every ✨ mode** — "picture N" in the prompt brings the References docker's picture to Edit, Generate, Fill, Remove, Refine (through the edit model); "ref N" in Compose. *Where:* the image editor's ✨ AI panel, the prompt docker. *Since:* 2.556.0
- **AI fill models add-on** — the node pack + the Fooocus / MAT / inpainting ControlNet files for the Krita-way fill, ticked and downloaded from Settings ▸ Add-ons. *Where:* Settings ▸ Add-ons ▸ AI fill models. *Since:* 2.557.0
- **▣ dockers take every docker** — in the floating band with the other floating dockers (not on top of all), outlined while a docker is dragged; Settings, References, Assets, Queue, Gallery and the StoryBoard drag in by their title bar. *Where:* the statusbar's ▣ Docker (Ctrl+Alt+D). *Since:* 2.558.0
- **Folder filters remember their folder; Basic Settings in basic.cfg** — each folder filter dropdown keeps the folder you picked (folder_filters.cfg); Basic Settings are saved to basic.cfg when changed and read back at the start. *Where:* any model dropdown's folder filter, the 📁 browser, the Model manager; Basic Settings. *Since:* 2.559.0
- **▣ dockers dock, and every docker goes in** — a floating ▣ docker dragged by its title bar docks above / below / beside a docker or in a side docker (the blue drop zones); Basic Settings, LLM tokens and the prompt docker drop into a ▣ docker and float out again. *Where:* the statusbar's ▣ Docker (Ctrl+Alt+D). *Since:* 2.560.0
- **A ▣ docker as a column of its own** — dropped on the seam between two columns (or at the window's edge) it becomes a full-height column with its own splitter; kept across restarts. *Where:* drag a ▣ docker by its title bar. *Since:* 2.561.0
- **Resumed jobs come back to their scene; nothing autoplays** — a StoryBoard scene interrupted by a restart takes its job back (running, its progress bar) when ▶ Resume is pressed in the Queue docker's Pending tab; videos and songs load paused until ▶ / Space. *Where:* the Queue docker's Pending tab; the StoryBoard; the player. *Since:* 2.562.0
- **Pictures from other scenes; 🅰 Picture A first frames** — the scene pickers' 🎬 Scenes tab (every scene's own pictures) and 🎞 Clips (any take's frames); ✎ First frame starts from a chosen Picture A (style, composition, poses kept) in a new or the global prompt's location, the instruction written by the LLM (🤖 Write). *Where:* the StoryBoard scene cards. *Since:* 2.563.0
- **🎙 Voice chat** — talk to the app hands-free, like a live chat: it hears you (faster-whisper, local, kept loaded), the local LLM answers out loud and does what you ask - the prompt, styles, Basic Settings, Generate, StoryBoard scenes, dockers. *Where:* the statusbar's 🎙 Voice (Ctrl+Alt+V). *Since:* 2.564.0
- **The StoryBoard grid; 🎞 Write storyboard** — scenes as Model-manager-like cards in a grid with ➜ to the next, a click opens the full scene card; the LLM writes the scenes and every scene gets its storyboard picture as its starting (First) frame. *Where:* the StoryBoard (▦ / ☰, 🎞 Write storyboard, ☑ Start on it). *Since:* 2.565.0
- **MOSS-Image** — OpenMOSS's 5B image model as two image styles (SFT, Base); Settings ▸ Add-ons ▸ MOSS-Image downloads the model, text encoder and VAE you tick into ComfyUI and checks ComfyUI is new enough. *Where:* Settings ▸ Add-ons; Settings ▸ Image (the styles). *Since:* 2.566.0
- **Theme editor: alignment, padding, margins, corners** — the Style panel lines text up (left / centre / right / justified, top / middle / bottom - buttons, flex rows / columns, grids and blocks of words), sets padding and margins for the element and for its words (each side, = for all four), and rounds each corner on its own. *Where:* 🖌 Edit theme mode ▸ click an element ▸ Text / Box. *Since:* 2.567.0
- **StoryBoard pictures written by the LLM** — 🖼 sends a scene back to the LLM to write its opening frame's picture prompt, with the character sheets and the scene before's last frame (when it has a take) as references; 📁 changes the picture (another scene's picture, a take's frame, a project picture or a file); the picture fills the whole card in the grid. *Where:* StoryBoard ▸ ▦ grid ▸ a card's 🖼 / 📁; the bar's ☑ LLM writes it / ☑ Previous last frame. *Since:* 2.568.0
- **🔲 Zones (image editor)** — boxes on the canvas, each with what goes in it; filled one box at a time (✨ Generate per box), by the Edit model in one pass (the boxes outlined on a copy), or as a regional prompt in one pass (a new picture, each box's words only inside it). *Where:* Image editor ▸ ✨ AI panel ▸ 🔲 Zones; the Zones tool with the marquees. *Since:* 2.569.0
- **🎭 Regional character LoRAs** — a zone's 🎭 picks a character LoRA that works only inside that box (two different LoRAs at most), so two characters keep their own faces in one picture; the scene's words over the whole. *Where:* Image editor ▸ ✨ AI ▸ 🔲 Zones ▸ ▦ Regional (Settings ▸ Add-ons ▸ Nougan Nodes). *Since:* 2.592.0
- **🖊 Pen tablet (image editor)** — pen pressure with a curve (presets or your own), lightest-touch / full-pressure window, the levels your pen sends, tilt, the eraser end and the side button; pressure → size / opacity for every brush; 7 pen brushes (G-pen, Mapping pen, Brush pen, Real pencil, Fineliner, Technical pen, Calligraphy). *Where:* Image editor ▸ 🖊 Pen tab (next to 🖌 Brush), Window ▸ Pen Tablet; the brush presets ▾. *Since:* 2.570.0
- **Multi-select + drag several clips; ⛓ Sequential** — Ctrl / Shift-click several clips in the Gallery, Assets or References and drag them onto the timeline together (oldest on the top layer, one after the other); ⛓ Sequential keeps the timeline's clips playing one after the other down the layers with no gap after deletes, new layers and trims. *Where:* Gallery / Assets / References (Ctrl / Shift-click, drag); the timeline bar ▸ ⛓ Sequential. *Since:* 2.571.0
- **✨ Auto transition; 🔇 Video sound** — a transition of N frames at every cut between video clips on different layers, no clip moved (the lip sync with the song stays exact - the clip before is held under the next one); one button mutes / unmutes every video layer so the full song plays alone. *Where:* the timeline bar ▸ ✨ Auto transition [frames] [type], 🔊 Video sound. *Since:* 2.572.0
- **✂ Song cut duration** — the StoryBoard song strip auto-cuts on any grid (2-60 s; 29.9 = one Long video run per scene); locked segments stay; remembered. *Where:* the song strip's menu bar ▸ ✂ [s]. *Since:* 2.573.0
- **⤓ Update ComfyUI; update check on startup** — ComfyUI updated in place (the portable build's own updater, or git + pip), Newest or Stable channel, a ComfyUI the app started restarted; a look at GitHub for bitGen Studio and ComfyUI after start, a ⬆ in the status bar when either is newer. *Where:* Settings ▸ ComfyUI ▸ ⟳ ComfyUI updates; Settings ▸ General ▸ ⟳ Updates ▸ Check for updates on startup. *Since:* 2.573.0
- **FastH3 Omni** — MiniMax H3's reference-to-video in 8 steps (FastVideo): a video style, a StoryBoard Workflow, an add-on that downloads it, and its recipe (shift 12/3, VSA, 8 steps) on any H3 graph that loads it. *Where:* Settings ▸ Add-ons ▸ FastH3 Omni; StoryBoard ▸ Workflow ▸ FastH3 Omni. *Since:* 2.573.0
- **Rename docker titles and any words in theme edit mode** — a docker's title bar and any element with words beside buttons / boxes get new words (caret and buttons kept, a collapse keeps them). *Where:* 🖌 theme edit mode ▸ pick ▸ Layout ▸ Text. *Since:* 2.574.0
- **Step n of total everywhere** — pictures (ComfyUI and sd-cli), music and video report their sampler steps live, and every docker, dialog and card that shows a running generation says step n of total. *Since:* 2.574.0
- **Theme edit ▸ Apply to: This element only (default)** — every pick starts on just that element; new words never spread to other dockers or elements. *Where:* 🖌 theme edit mode ▸ Apply to. *Since:* 2.574.1
- **Model manager: your files, thumbnail, metadata** — pictures / videos / sounds of a model with their prompt + seed / cfg / steps (read from the file or the render), a click opens the viewer, ✎→ to the prompt, 🖼 as the thumbnail. *Where:* 🧩 Model manager ▸ ⓘ ▸ Your pictures, videos and sounds; ✎ Edit ▸ Thumbnail. *Since:* 2.575.0
- **Model manager: half-star rating, model type, NSFW** — a five-star editor in half steps, the model type (checkpoint, LoRA …) and an NSFW flag; the filter bar filters by both. *Where:* 🧩 Model manager ▸ ✎ Edit; the filter bar. *Since:* 2.575.0
- **✎→ To prompt from any file** — a file's prompt with its seed, cfg and steps to the prompt box + Basic Settings. *Where:* the gallery, Assets, References tiles; the viewer's ⓘ details. *Since:* 2.575.0
- **Civitai sync in the status bar** — 🔄 Civitai n/total while it syncs, ✓ synced with the counts when it finishes. *Since:* 2.575.0
- **Dockers restored as left** — ▣ docker membership, tab order, shown tab, hidden / collapsed, minimized floating panels, extension dockers - kept over a restart. *Since:* 2.575.0
- **Civitai sync by SHA-256** — a model not found by its name is found by its file's content; the status bar shows reading n%. *Where:* 🧩 Model manager ▸ 🔄 Sync. *Since:* 2.576.0
- **🧩 To model… / Ctrl+↓ thumbnail** — the viewer sends a picture / video / song to a model's files with its metadata; Ctrl+↓ makes a picture the model's thumbnail. *Where:* the viewer; 🧩 Model manager ▸ ⓘ. *Since:* 2.576.0
- **Your own pose sheets** — the Character creator's 🧍 Pose sheet dialog shows thumbnails of the pictures in the pose_sheets folder; the picked one gives the character sheet its panels, poses and camera angles. *Where:* StoryBoard ▸ 🖼 NEW (Character creator) ▸ Sheet ▸ Pose sheet; the pose_sheets folder. *Since:* 2.577.0
- **📐 SolidCraft docker** — open-source parametric 3D CAD (SolidCraft, MIT OR Apache-2.0) in its own docker, every SolidCraft feature; designs and parts kept in the project, SolidCraft's Save keeping them current; a picture of the model (or SolidCraft's render) into the image editor, the model as a timeline 3D layer, image editor sketch layers into SolidCraft, STEP / STL / OBJ / 3MF into the project. *Where:* 📐 SolidCraft in the status bar; Settings ▸ Add-ons ▸ SolidCraft. *Since:* 2.578.0
- **Send from SolidCraft** — the part to the image editor, the timeline, the House builder (a piece at its own size), Blender (opens with it, saved as a .blend - shown when Blender is found) and Unreal (a Static Mesh placed in the level - shown when an Unreal project is set; plugin 1.4.0); the docker shows only when SolidCraft is installed. *Where:* 📐 SolidCraft's bar. *Since:* 2.579.0
- **The installed ComfyUI's models, without setting it up** — with no ComfyUI folder in Settings, the ComfyUI on this computer is found (environment, beside the app, home, Pinokio, Stability Matrix, drive tops, ComfyUI Desktop) and its checkpoints and diffusion models are listed in the Model manager and Basic Settings; Use this folder sets it. *Where:* 🧩 Model manager; Basic Settings ▸ Model / checkpoint; Settings ▸ ComfyUI ▸ Folder. *Since:* 2.622.0
- **Delete a model from the disk** — the file, the files beside it and its model_info page, after a confirmation that lists them and the styles using it. *Where:* 🧩 Model manager ▸ 🗑 on a card / ⓘ ▸ 🗑 Delete. *Since:* 2.579.0
- **Settings ▸ Dockers** — every docker and floating window (extensions included) with where it is and ↺ Reset to its default place and size; ↺ Reset all. *Where:* Settings ▸ Dockers. *Since:* 2.579.0
- **Model paths (extra_model_paths.yaml)** — every group of ComfyUI's extra model paths: ➕ a new group (other_ui1, other_ui2 …, filled from the folders under its base), change / add / remove a path (📁 picks it), rename, is_default, 🗑 delete a group; the rest of the file kept, a .bak of the last; ⟳ Restart ComfyUI. *Where:* 🧩 Model manager ▸ 📁 Model paths. *Since:* 2.580.0
- **Civitai videos and animated pictures** — 🔄 Sync / ⤓ Civitai info keep a model's video and GIF examples too; a video thumbnail plays on the card and its ⓘ page, the viewer plays it; a video can be a card's thumbnail. *Where:* 🧩 Model manager. *Since:* 2.581.0
- **LoRA keywords in LLM prompts** — ✨ Enhance and the prompt chat write the selected LoRAs' keywords (trigger words) into the prompt; Enhance adds any the LLM left out. *Where:* Prompt docker ▸ ✨ Enhance / the prompt chat. *Since:* 2.581.0
- **✨ Generate a part in SolidCraft** — a description or a picture -> CadQuery code (cadrille, or the local LLM with error repair) -> SolidCraft's own editable sketches, extrudes, cuts, holes, fillets and chamfers (checked by volume; else the STEP as one solid); the code editable and run again. *Where:* 📐 SolidCraft ▸ ✨ Generate; Settings ▸ Add-ons ▸ CAD generate. *Since:* 2.581.0
- **Fibo 2.0 (edit, low VRAM)** — Bria's 8B model as two image styles: Edit Turbo (4-step instruction edits) and Dev (text to image + edits); up to 4 pictures <image_1>..; the w4a8 or GGUF Q4_0 files for about an 8 GB card; downloaded from Settings ▸ Add-ons ▸ Fibo 2.0 (CC BY-NC 4.0). *Where:* image editor ▸ ✨ AI ▸ Edit; Settings ▸ Image. *Since:* 2.582.0
- **Team ▸ render farm** — a team on a NAS folder: the leader approves members and their bitGen issues every member a signed key each day; everyone opens the same projects; a PC's owner lets members render on it (unrestricted or from - to) only while bitGen runs there and sharing is on; 🖥 Render on: This PC / a member's PC / ⚡ Spread, with the team's renders and progress. Same network or Tailscale. 2.589.0: an OPTIONAL add-on (its own zip - it may trigger virus checkers). *Where:* Settings ▸ Add-ons ▸ Team render farm, then Settings ▸ Team; the status bar's 🖥 chip. *Since:* 2.583.0
- **🔁 Compare LLMs** — one prompt answered by each ticked LLM in turn, each reply in the chat under its name; ✓ Use this one makes it the answer, every round (request, every reply, the choice, the time) is recorded and 🏆 shows the best LLM for each job (screenplay, music video, song, image / video prompt, chat) with win %, average time and a CSV export. *Where:* the prompt docker's menubar (🔁 ▾ 🏆). *Since:* 2.584.0
- **Train an LLM on your picks** — 🔁 Compare LLMs rounds keep the full prompt; 🏆 ▸ 🎓 sends the picked replies (examples) and picked-vs-not pairs into the trainer's LLM job; the trainer learns from Examples (SFT) or Preferences (DPO / ORPO, Beta) and writes a new .gguf. *Where:* 🏆 ▸ 🎓 Train an LLM on your picks; 🎓 LoRA trainer ▸ Job ▸ Learn from, Dataset ▸ 🔁 Preference pairs. *Since:* 2.585.0
- **Add-ons ▸ LLM** — the chat / writing LLMs in one dropdown (★ Qwen3.8 27B - the base for your own checkpoint, Gemma 4 31B / 12B, Qwen3.5 9B, Qwen3 4B / 8B / 14B), downloaded into the LLM folder; the trainer's Qwen3.8 27B base trains as a 4-bit QLoRA on a 32 GB card. *Where:* Settings ▸ Add-ons ▸ LLM; 🎓 LoRA trainer ▸ Base model. *Since:* 2.586.0
- **⤒ Import & check a ComfyUI workflow** — any saved / API workflow: its picture / video / sound inputs counted, a preview made a save, missing nodes and model files reported, Prompt / Negative / Seed / Steps / CFG / size / length controls wired, the graph drawn; ▶ Test run with test inputs - saved into comfy_workflows/ + a graph when it works, ComfyUI's errors when it does not. *Where:* Settings ▸ ComfyUI ▸ Graphs. *Since:* 2.587.0
- **Dockers on / off + layouts** — 👁 turns a docker and its status-bar button off; 🗂 Layouts saves / applies / exports / imports the whole docker arrangement with the theme (layouts/<name>.json); ★ Save as the default = layouts/default.json + themes/default.json for a fresh install. *Where:* Settings ▸ Dockers. *Since:* 2.587.0
- **⚡ Live generation (image editor)** — Krita's live mode: every change is rendered again a moment later (a whole-picture Refine at the live strength, its own style / steps / size / 🔒 seed), one render at a time with the newest change winning, the model kept loaded, front of the queue, never in the queue docker / gallery; ▣ on canvas with a mix; ✔ Apply as layer. *Where:* Image editor ▸ ⚡ (menu bar) / View ▸ ⚡ Live Generation. *Since:* 2.588.0
- **🎨 Artist mode (image editor)** — only the canvas, full screen and frameless; Ctrl+P the colour palette at the pointer (square + hue strip, chips, recent), Ctrl+B the brushes (presets, size, opacity, flow), Ctrl+Esc (or Ctrl+Shift+F) back. *Where:* Image editor ▸ 🎨 Artist mode (right after the menus) / View ▸ Artist Mode. *Since:* 2.588.0 (named Artist mode in 2.590.0)
- **🧬 RefMods library** — MiniMax H3 reference mods for every project in refmod/<name>/: 7 types (character, location, vehicle, object, prop, flora, animal), media uploaded and sorted into images / videos / audio, ✨ autocaption with the vision model, 🧬 Extract (pictures + video frames) -> the .safetensors kept in the folder, @name in a prompt uses it. *Where:* 🎓 LoRA & fine-tune trainer ▸ 🧬 RefMods. *Since:* 2.588.0
- **SolarRenderer** — a structure video (+ first frame, six-part prompt) -> the clip in 4 steps on MiniMax H3: the node pack + LoRAs as an add-on, its workflows imported through ⤒ Import & check. *Where:* Settings ▸ Add-ons ▸ SolarRenderer; Settings ▸ ComfyUI ▸ Graphs ▸ ☀ SolarRenderer. *Since:* 2.588.0
- **Optional extensions with a server part** — an extension (ext/<id>/) can bring its own server code (ext.json "server"), mounted at start and shown only while it runs; Settings ▸ Add-ons installs one from its zip (📦) and removes it. The Team render farm is one - kept out of the install zips because it may trigger virus checkers. *Where:* Settings ▸ Add-ons ▸ Team render farm. *Since:* 2.589.0
- **Every image editor tab is a docker** — drag a tab out = it floats; onto another docker = a tab of it; onto the panel column's edge = a docker of its own there; ⠿ drags a whole docker; kept; Window ▸ Show All Dockers / Reset Docker Tabs. *Where:* the image editor's panels. *Since:* 2.590.0
- **📺 Unreal View** — the selected Unreal / MetaHuman layer's (image editor) or Unreal clip's (timeline, at the playhead) camera, live from Unreal; S / M / L, ⏸, ⚡ keep Unreal fast behind bitGen. Unreal must run, not be in front. *Where:* image editor (opens with an Unreal layer); timeline UNREAL ▸ View ▸ 📺 Unreal View. *Since:* 2.590.0 (bitGen Bridge 1.5.0)
- **LoRA keywords from the LoRAs in use** — ✨ Enhance and the prompt chat write only the keywords of Basic Settings' temporary LoRAs (Override style on) or of the selected style's LoRAs (off). *Where:* Basic Settings ▸ Override style; the style's LoRAs. *Since:* 2.585.0

### Selections

- **Marquee, lasso and magic wand** — Shift adds, Alt subtracts, Shift+Alt intersects; feather softens the next selection. *Where:* M, L, W
- **The Select menu** — All, Deselect, Reselect, Inverse, Color Range, Modify (Border, Smooth, Expand, Contract, Feather), load a layer's transparency or mask. *Where:* the Select menu
- **Quick Mask** — the selection shown in red; paint to add, erase to remove. *Where:* Q
- **Segment Anything** — click a thing to select it, Shift-click for more, or drag a box; runs on this computer after a one-time install. *Where:* the Object Selection tool (W). *Since:* 2.390.0
- **Select Subject** — the main subject selected in one step: built in (no download) or the AI matte (BiRefNet on this computer). *Where:* Select > Subject, Subject Settings. *Since:* 2.488.0
- **Remove Background** — the subject put into the layer's mask, the background hidden. *Where:* Layer > Remove Background. *Since:* 2.488.0
- **Find by words** — type what to select ("the person's head", "dog, car") and select it or make it a mask. *Where:* the Object Selection options bar, Select > Subject. *Since:* 2.390.0
- **Segment Layer** — split a layer into its parts, each on its own layer in a group. *Where:* Layer > Segment Layer. *Since:* 2.390.0
- **Select and Mask** — a workspace with Quick Selection, Refine Edge and Brush, views, edge radius, smooth, feather, contrast, shift edge, decontaminate colours and output to a selection, mask or new layer. *Where:* Select > Select and Mask (Alt+Ctrl+R). *Since:* 2.423.0
- **Magnetic Lasso** — the line snaps to an edge as you move along it. *Where:* L. *Since:* 2.423.0
- **Quick Selection** — paint and the selection grows to the edges, with Auto-Enhance. *Where:* W. *Since:* 2.423.0
- **Select Sky** — the sky reaching the top edge, soft along the skyline. *Where:* Select > Sky. *Since:* 2.423.0
- **Saved selections** — save a selection into an alpha channel and load it again. *Where:* Select > Save Selection, Load Selection. *Since:* 2.423.0
- **Mask overlay** — what a mask hides shows red while you paint it, or all the time. *Where:* View > Mask Overlay. *Since:* 2.391.0

### Painting and retouching

- **Brush and Pencil** — 20 brush presets (plus yours and imported .abr brushes), number keys for opacity, pen pressure for size and flow; a hard-edged pencil. *Where:* B
- **Brush Settings** — tip angle, roundness and flips; shape dynamics, scattering, texture, dual brush, colour dynamics, transfer and smoothing, kept per preset. *Where:* the Brush tab. *Since:* 2.484.0
- **Brush presets and .abr brushes** — save the current brush as your own preset (brushes/<name>.json) and import the sampled brushes of .abr brush files. *Where:* the Brush tab. *Since:* 2.484.0
- **Clone Stamp and History Brush** — clone from a source; paint a layer back as it was opened. *Where:* S and Y
- **Eraser, Dodge, Burn, Sponge, Blur, Sharpen, Smudge** — the classic retouching brushes. *Where:* E, O and R
- **Spot Healing** — content-aware or proximity match, filled from around the spot. *Where:* J. *Since:* 2.423.0
- **Healing Brush** — the copy takes the colour and light of where it lands. *Where:* J. *Since:* 2.423.0
- **Patch** — drag a selection onto clean texture; Normal mode with Transparent and Diffusion, or Content-Aware with Structure and Color. *Where:* J. *Since:* 2.423.0
- **Content-Aware Move** — move or copy a thing; its old place is filled, with Structure and Color settings. *Where:* J. *Since:* 2.423.0
- **Red Eye** — click the red pupil. *Where:* J. *Since:* 2.423.0
- **Content-Aware Fill** — fill a selection from the rest of the picture, with no AI. *Where:* Edit > Content-Aware Fill, Edit > Fill. *Since:* 2.423.0
- **The Content-Aware Fill workspace** — choose the sampling area (auto, rectangular or painted), see a live preview, set colour adaptation and the output layer. *Where:* Edit > Content-Aware Fill. *Since:* 2.448.0
- **Mixer Brush** — the paint picks up the canvas's colour as it goes. *Where:* B. *Since:* 2.423.0
- **Background and Magic Eraser** — erase what is like the colour under the brush, or a whole area of one colour. *Where:* E. *Since:* 2.423.0
- **Gradient tool** — linear, radial, angle, reflected or diamond. *Where:* G
- **Paint Bucket** — fill with the foreground, the background or a gradient, with tolerance, contiguous and all layers. *Where:* G, Shift+G. *Since:* 2.396.0
- **Crop** — drag a box, pick a ratio, Enter crops. *Where:* C

### Transforms and warps

- **Free Transform** — move, scale, rotate, or type X, Y, W, H and the angle. *Where:* Ctrl+T
- **Skew, Distort, Perspective and Warp** — corners along their sides, anywhere, in mirror, or a warp grid with presets and a bend. *Where:* Edit > Transform. *Since:* 2.422.0
- **Warp grids and split lines** — 3 x 3 to custom grids; split the warp crosswise, vertically or horizontally for more points. *Where:* Edit > Transform > Warp. *Since:* 2.450.0
- **Puppet Warp** — place pins and drag them to bend the layer naturally. *Where:* Edit > Puppet Warp. *Since:* 2.422.0
- **Pin depth and rotation** — which part goes on top where it folds; a pin's turn held fixed or left free. *Where:* the Puppet Warp options bar. *Since:* 2.465.0
- **Content-Aware Scale** — narrower or wider while faces, objects and edges keep their shape; protect the selection. *Where:* Edit > Content-Aware Scale (Alt+Shift+Ctrl+C). *Since:* 2.422.0
- **Liquify** — forward warp, reconstruct, twirl, pucker, bloat, freeze and thaw masks. *Where:* Filter > Liquify (Shift+Ctrl+X). *Since:* 2.422.0
- **Liquify extras** — Smooth, Push Left and face-aware sliders for the eyes, nose, mouth and face shape. *Where:* Filter > Liquify. *Since:* 2.450.0
- **Move tool handles** — one click for scale handles, a double-click for rotate and skew handles; type stays editable and shapes stay vector. *Where:* V. *Since:* 2.452.0
- **Transform options** — angle, rotate by 90, flips and W x H percentages round the centre. *Where:* the Move tool's options bar. *Since:* 2.452.0

### Smart objects and smart filters

- **Smart objects** — a layer or group goes inside and stays editable; scaling, turning and warping lose nothing. *Where:* Layer > Smart Objects. *Since:* 2.422.0
- **Edit Contents** — open the inside, change anything, and every copy follows. *Where:* double-click the thumbnail. *Since:* 2.422.0
- **Replace, export, convert, rasterize** — replace the contents from a file, export them, turn them back into layers or plain pixels; New Smart Object via Copy makes an independent one. *Where:* Layer > Smart Objects. *Since:* 2.422.0
- **Smart filters** — any filter or adjustment on a smart object is added as a re-editable filter: on / off, settings, opacity, order. *Where:* the rows under the layer. *Since:* 2.422.0
- **Filter mask** — paint where the smart filters show. *Where:* the Smart Filters row. *Since:* 2.422.0
- **Smart filter blend modes** — 24 blend modes and an opacity per smart filter. *Where:* right-click a smart filter. *Since:* 2.434.0
- **Linked smart objects** — the contents live in a file in the project's linked folder; change the file and the layer follows. *Where:* File > Place Linked. *Since:* 2.469.0
- **Convert, embed and relink** — make an embedded smart object linked, embed a linked one, or relink it to another file; a missing file is flagged. *Where:* Layer > Smart Objects. *Since:* 2.469.0

### Adjustments, filters and layer styles

- **Image adjustments** — all 24 adjustments applied to the pixels, plus Auto Tone, Auto Contrast and Auto Color. *Where:* Image > Adjustments
- **Shadows / Highlights and HDR Toning** — local tone: lift the shadows and hold the highlights by amount, tone and radius; the HDR look with edge glow, gamma, exposure and detail. *Where:* Image > Adjustments. *Since:* 2.480.0
- **Selective Color** — add or take away cyan, magenta, yellow and black in nine colour ranges, relative or absolute; also an adjustment layer. *Where:* Image > Adjustments, Layer > New Adjustment Layer. *Since:* 2.480.0
- **Replace Color and Match Color** — pick a colour on the picture and shift its hue, saturation and lightness; give a layer the colour of another layer, the merged picture or a file. *Where:* Image > Adjustments. *Since:* 2.480.0
- **Color Lookup** — 3D LUTs: the timeline's looks and .cube files from the shared LUT library, mixed by an amount; also an adjustment layer. *Where:* Image > Adjustments. *Since:* 2.480.0
- **Apply Image** — blend another layer, the merged picture or one of their channels onto a layer with 11 modes, opacity and invert. *Where:* Image > Apply Image. *Since:* 2.480.0
- **Image size and canvas** — Image Size, Canvas Size with an anchor, rotation, crop to the selection and trim. *Where:* the Image menu
- **Filters** — blur, distort, noise, pixelate, render, sharpen and stylize filters, each previewed live; Ctrl+F repeats the last. *Where:* the Filter menu
- **Lens Flare, Swirl, Drop Shadow, 3D Extrude** — click the picture to place a flare or swirl centre. *Where:* the Filter menu. *Since:* 2.397.0
- **Blur set and Blur Gallery** — Surface, Smart and Lens Blur (depth, iris blades, bokeh highlights), Average; Field, Iris, Path and Spin Blur with click-to-place centres. *Where:* Filter > Blur, Filter > Blur Gallery. *Since:* 2.481.0
- **Noise and Smart Sharpen** — Reduce Noise, Dust & Scratches, Despeckle; Smart Sharpen that removes Gaussian, lens or motion blur and fades in the shadows and highlights. *Where:* Filter > Noise, Filter > Sharpen. *Since:* 2.481.0
- **Other filters** — High Pass, Minimum, Maximum, Offset, a Custom 5 x 5 kernel and HSB / HSL. *Where:* Filter > Other. *Since:* 2.481.0
- **Distort and Pixelate sets** — Displace (a map from a layer), Polar Coordinates, Pinch, ZigZag, Shear, Glass; Color Halftone, Crystallize, Pointillize, Facet, Fragment, Mezzotint. *Where:* Filter > Distort, Filter > Pixelate. *Since:* 2.481.0
- **Lighting Effects and render set** — spot, point and infinite lights with a height texture; Fibers and Difference Clouds; Diffuse, Tiles and Trace Contour. *Where:* Filter > Render, Filter > Stylize. *Since:* 2.481.0
- **Artistic, Sketch and Texture** — Cutout, Poster Edges, Watercolor, Dry Brush, Graphic Pen, Charcoal, Grain and Craquelure. *Where:* Filter > Artistic, Sketch, Texture. *Since:* 2.481.0
- **Develop Filter** — a photo developer: white balance, exposure, tone, texture, clarity, dehaze, vibrance, a tone curve, an eight-colour mixer, black & white, colour grading, sharpening and noise reduction, optics, geometry, grain and vignettes, with presets and your own. *Where:* Filter > Develop Filter (Alt+Shift+Ctrl+A). *Since:* 2.482.0
- **Lens Correction** — remove barrel or pincushion distortion, colour fringes and vignetting; fix perspective, angle and scale with a grid; fill the edges. *Where:* Filter > Lens Correction (Alt+Shift+Ctrl+R). *Since:* 2.482.0
- **Navigator, Histogram, Info and Notes panels** — the view box over a small picture; channel histograms with statistics; RGB, HSB and CMYK under the pointer with colour samplers; every note listed. *Where:* the Color panel group, Window menu. *Since:* 2.483.0
- **Color Sampler, Ruler, Note and Count tools** — up to ten samplers, a ruler that straightens a layer or the picture, pinned notes and numbered count groups. *Where:* the Eyedropper's tool group (I). *Since:* 2.483.0
- **Perspective Crop** — four corners onto what should be square; Enter crops and squares the whole picture. *Where:* the Crop tool's group (C). *Since:* 2.483.0
- **Grow, Similar, Focus Area, Transform Selection, Matting** — grow or extend a selection by colour, select the sharp parts, move / scale / rotate the selection; defringe and remove black or white mattes. *Where:* the Select and Layer menus. *Since:* 2.483.0
- **Quick Adjust and Filter menus** — work on the active layer, only inside the selection when there is one. *Where:* the image editor
- **Layer styles** — drop shadow, inner shadow, outer and inner glow, stroke, colour, gradient and pattern overlay, bevel and emboss, satin; copy and paste them. *Where:* fx, or double-click a thumbnail
- **Style presets** — one-click Gold, Chrome, Neon, Embossed, Glass, 3D Pop, Retro, Fire, Ice and Letterpress. *Where:* the Layer Style dialog. *Since:* 2.397.0

### Type

- **Horizontal, Vertical and Type on a Path** — the letters follow a drawn line; move the start or flip the side. *Where:* T, Shift+T. *Since:* 2.397.0
- **All caps, underline, strikethrough, vertical** — buttons in the Type options bar. *Where:* the Type options bar. *Since:* 2.397.0
- **Text shape and 3D** — eleven warps, text round a circle, along a path, or extruded 3D letters, all still editable. *Where:* Layer > Text Shape. *Since:* 2.397.0
- **Character panel** — font, style, size, leading, kerning, tracking, scales, baseline shift, faux bold and italic, small caps, super- and subscript. *Where:* Window > Character. *Since:* 2.426.0
- **Paragraph panel** — alignment, justify, indents, space before and after, hyphenate. *Where:* Window > Paragraph. *Since:* 2.426.0
- **Paragraph text** — drag a box with the Type tool and the text wraps inside it; convert between point and paragraph text. *Where:* T. *Since:* 2.426.0
- **Character and paragraph styles** — make, apply, clear overrides and redefine styles. *Where:* the Character and Paragraph panels. *Since:* 2.426.0
- **Per-character settings** — select letters while typing and change only their font, size, colour or any Character setting. *Where:* the Type tool. *Since:* 2.449.0
- **OpenType features** — ligatures, alternates, swash, ordinals, fractions, figure styles, small caps and stylistic sets from the font's own file. *Where:* the Character panel. *Since:* 2.466.0
- **Optical kerning** — letters spaced from their shapes. *Where:* the Character panel. *Since:* 2.466.0
- **Type to outlines** — convert text to a shape layer of its outlines, or create a work path from it. *Where:* Layer > Type. *Since:* 2.466.0
- **Text in a shape** — click inside a shape with the Type tool and the text flows inside its outline. *Where:* the Type tool. *Since:* 2.466.0
- **Text effect presets** — the same layered 3D text presets as the timeline, drawn live. *Where:* the Type options bar, a text layer's Properties. *Since:* 2.411.0
- **Presets through every shape** — warp, round a circle, along a path, vertical and 3D keep the text's preset (3D sides in its colour, darker). *Where:* ⌒ Shape / 3D… *Since:* 2.607.0
- **Fill a shape with text** — flow the text inside a shape (Fit sizes it), stretch it to fill the outline, or repeat it in rows as the shape's fill. *Where:* right-click a shape, the Shape tool's bar, Layer ▸ 🅰 Fill Shape with Text…. *Since:* 2.608.0
- **16 warp presets** — Shell Lower, Shell Upper, Fisheye, Twist and Wedge join Arc … Squeeze. *Where:* ⌒ Shape / 3D…, Edit ▸ Transform ▸ Warp. *Since:* 2.608.0
- **Warp grid on text and shapes** — drag the grid's points (presets, 3 x 3 … 5 x 5, split lines); the text stays typeable, the shape editable, the warp follows. *Where:* ⌗ Warp Grid in the Type / Shape tools' bars, right-click. *Since:* 2.608.0

### Pen, paths and vector masks

- **Pen** — corner and smooth anchors, close, cusp, 45-degree steps, auto add and delete. *Where:* P. *Since:* 2.421.0
- **Freeform Pen and point tools** — draw by hand and fit curves; add, delete and convert anchor points. *Where:* Shift+P. *Since:* 2.421.0
- **Curvature Pen and Rubber Band** — the curve bends smoothly through the points you click; preview the next segment. *Where:* P. *Since:* 2.425.0
- **Path Selection** — move, copy, combine and transform whole components; align and distribute them. *Where:* A. *Since:* 2.421.0
- **Direct Selection** — anchors and handles, nudge, corner or smooth. *Where:* A. *Since:* 2.421.0
- **Shape or Path mode** — draw a shape layer or the work path; combine, subtract, intersect or exclude. *Where:* the options bar. *Since:* 2.421.0
- **Custom Shape tool** — heart, star, burst, arrow, speech bubble, cloud and more, plus your own. *Where:* U, Edit > Define Custom Shape. *Since:* 2.421.0
- **The Paths panel** — the work path, saved paths, shape paths and vector masks; fill, stroke, make a selection or a mask. *Where:* the Paths tab. *Since:* 2.421.0
- **Vector masks** — reveal all, hide all, the current path; density, feather, invert, link and rasterize. *Where:* Layer > Vector Mask. *Since:* 2.421.0
- **Paths follow the picture** — crop, canvas size, image size and rotate move the paths too. *Where:* the image editor. *Since:* 2.421.0
- **Round corners on any path** — round the picked corners of a path, a joined shape or a vector mask. *Where:* Direct Selection, the Radius box. *Since:* 2.466.0

### Vector lines and drawing tools

- **Bézier tool** — cusp and smooth nodes, 15-degree steps, close, or carry an open line on. *Where:* F5. *Since:* 2.425.0
- **Freehand, 2-Point Line, Polyline, 3-Point Curve, B-Spline, Node Pen** — the other curve tools. *Where:* F5 again. *Since:* 2.425.0
- **Arrowheads and line styles** — solid, dashed, dotted, dash-dot and custom lines, with start and end arrowheads (arrow, triangle, circle, square, diamond, bar and more). *Where:* the curve tools' property bar. *Since:* 2.425.0
- **Shape tool (nodes)** — pick and drag nodes, handles and segments; add, delete, join, break, reverse, close and reduce nodes. *Where:* F10. *Since:* 2.425.0
- **Outline Pen** — colour, width, dashes, corners, caps, position, arrowheads, behind fill, scale with object. *Where:* F12. *Since:* 2.425.0
- **Convert to Curves** — a rectangle, ellipse, polygon or line becomes an editable vector line. *Where:* Ctrl+Q. *Since:* 2.425.0
- **Vector line and path** — a line becomes a path that remembers its outline, and back again. *Where:* Layer > Vector Line. *Since:* 2.425.0
- **Shape tools** — rectangle with per-corner round, scallop or chamfer corners, 3-point rectangle, ellipse with pie and arc, 3-point ellipse, polygon, star, complex star, spiral, graph paper and common shapes, all live. *Where:* F6. *Since:* 2.428.0
- **Draw modes into a shape** — new, add, subtract, intersect or exclude a new shape into the picked one. *Where:* the shape tools' bar. *Since:* 2.439.0
- **Artistic Media** — preset, calligraphic, pressure and sprayer strokes that become filled shapes. *Where:* F5. *Since:* 2.428.0
- **Connectors** — straight, right-angle or rounded lines that follow the objects they join. *Where:* F8. *Since:* 2.428.0
- **Callouts** — a 3-point callout with its text. *Where:* F8. *Since:* 2.428.0
- **Auto-fill** — a closed curve or new shape is filled with the colour picked last. *Where:* the curve tools' bar. *Since:* 2.430.0
- **Hover and pick highlight** — with the Move tool the object under the pointer is outlined in blue and the picked one in orange; a click on empty canvas picks nothing. *Where:* the Move tool. *Since:* 2.470.0
- **Move tool after drawing** — after a shape is drawn the Move tool is picked with the new shape selected (can be switched off). *Where:* the CAD toolbar's settings. *Since:* 2.470.0

### Dockers for vector work

- **Transform docker** — position, rotate, scale and mirror, size and skew about nine anchor points, with copies. *Where:* Window > Dockers (Alt+F7). *Since:* 2.429.0
- **Shaping docker** — weld, trim, intersect, simplify, front minus back, back minus front, boundary. *Where:* Window > Dockers. *Since:* 2.429.0
- **Align and Distribute** — to the active object, the selection, the page edge or centre. *Where:* Shift+Ctrl+A. *Since:* 2.429.0
- **Object Properties** — fill (uniform or gradient), outline and transparency of a vector shape. *Where:* Alt+Enter. *Since:* 2.429.0

### Frames and artboards

- **Frames** — place layers inside a closed shape; they show only within it and move, turn and scale with it. *Where:* Layer > Frame > Place Inside Frame. *Since:* 2.442.0
- **Edit and extract frame contents** — work on the contents alone, finish editing, or take them out. *Where:* double-click or right-click a frame. *Since:* 2.442.0
- **Locked frame contents** — the Move tool takes the frame and its handles transform the contents with it. *Where:* Lock Contents to Frame. *Since:* 2.453.0
- **Artboards** — several pages of their own size in one picture, from presets or your own size. *Where:* Layer > New > Artboard. *Since:* 2.447.0
- **Artboard tool and from group** — drag a new artboard, or turn a group into one. *Where:* V again, Layer > New > Artboard from Group. *Since:* 2.447.0
- **Export artboards** — each artboard as its own PNG. *Where:* File > Export > Artboards to Files. *Since:* 2.447.0

### Dimensions

- **Dimension tools** — parallel, horizontal / vertical and angular dimensions, with units at a dpi. *Where:* F8. *Since:* 2.428.0
- **Exact points** — dimensions snap to nodes, side middles, corners, outlines and guideline crossings, named as you hover. *Where:* the dimension tools. *Since:* 2.441.0
- **Live ends** — drag a dimension's end and its number follows. *Where:* the Move tool on a dimension. *Since:* 2.441.0
- **A scale per picture** — type a dimension's real size and unit and every dimension is measured with that scale. *Where:* the property bar. *Since:* 2.441.0
- **Dimension groups** — each dimension is a group of extension lines and a dimension line, redrawn from its measurements. *Where:* the Layers panel. *Since:* 2.457.0
- **Auto Dimension** — the picked object's overall width and height. *Where:* Layer > Auto Dimension. *Since:* 2.458.0
- **Floorplan Dimensions** — every wall of a closed shape dimensioned outside, plus the overall size. *Where:* Layer > Floorplan Dimensions. *Since:* 2.458.0
- **Chain Dimension tool** — a dimension between every two points along a line, plus the total. *Where:* F8. *Since:* 2.458.0

### Rulers, guidelines and snapping

- **Rulers in units** — pixels, millimetres, centimetres, inches or points. *Where:* View > Rulers (Ctrl+R). *Since:* 2.440.0
- **Guidelines** — drag out of a ruler, move, lock, type a place, list and clear. *Where:* View > Guidelines. *Since:* 2.440.0
- **Snapping** — to the grid, guidelines, objects, nodes, midpoints, intersections and the page; the Move tool snaps the layer's box. *Where:* View > Snap To. *Since:* 2.440.0
- **Grid button and settings** — spacing, major lines, lines or dots, colours and snap distance. *Where:* the top bar and the Grids and Guides settings. *Since:* 2.445.0

### Channels

- **Channels panel** — view RGB, Red, Green or Blue alone, or load a channel's lightness as a selection. *Where:* the Channels tab. *Since:* 2.423.0
- **Alpha channels** — saved selections you can view, load, rename and paint. *Where:* the Channels tab. *Since:* 2.423.0
- **Edit single colour channels** — painting, fills, filters and adjustments change only the picked channels. *Where:* the Channels panel (Ctrl+3 to Ctrl+5). *Since:* 2.467.0
- **Spot channels** — an ink colour and solidity shown over the picture, merged into a layer when you want. *Where:* the Channels panel, Select > New Spot Channel. *Since:* 2.467.0

### Colour, gradients and patterns

- **Colour swatches** — default colours, swap (which repaints a plain background), large outlined swatches. *Where:* D and X. *Since:* 2.396.0
- **The colour palette** — a strip of colours: click for the fill, right-click for the outline of a shape or type, or the foreground and background on pixels. *Where:* the right edge of the editor. *Since:* 2.430.0
- **Transparent swatch** — as the foreground a brush paints transparency. *Where:* the palette and Swatches panel. *Since:* 2.430.0
- **Gradient Editor** — presets plus your own, stops with colour, opacity and location; used by the Gradient tool, the bucket, fill layers and shapes. *Where:* Edit > Gradient Editor. *Since:* 2.434.0
- **Pattern library** — define patterns from the picture, pattern fill layers, fill with a pattern, and your patterns in Pattern Overlay. *Where:* Edit > Define Pattern, Pattern Library. *Since:* 2.437.0

### Actions and automation

- **Actions** — record menu commands, dialogs, filters and Layers panel changes, then play them; sets of actions with a default set. *Where:* the Actions tab (Alt+F9). *Since:* 2.427.0
- **Edit actions** — step on / off, stop in a dialog, insert stops and menu items, function keys, button mode, load and save. *Where:* the Actions tab. *Since:* 2.427.0
- **Batch** — play an action on many pictures or a folder, saved to the project, the gallery or downloads. *Where:* File > Automate > Batch. *Since:* 2.427.0
- **Brush strokes and hand-made selections recorded** — played back at the same place, scaled to the picture. *Where:* the Actions tab. *Since:* 2.468.0
- **Conditional steps** — if the document is landscape, portrait or square, has a selection, or a kind of layer, play one action, else another. *Where:* Actions > Insert Conditional. *Since:* 2.468.0
- **Image Processor** — save pictures as JPEG and / or PNG, resized, optionally after an action. *Where:* File > Scripts > Image Processor. *Since:* 2.468.0
- **Droplets** — a tile you drop pictures on to run an action on each. *Where:* File > Automate > Create Droplet. *Since:* 2.468.0
- **.atn action files** — load action sets from .atn files; matched steps play, the rest come in switched off. *Where:* Actions > Load Actions. *Since:* 2.469.0

### Files

- **New, Open and Save to Images** — a new picture in the background colour; save the visible picture into the project's Images. *Where:* File (Ctrl+N, Ctrl+O, Ctrl+S)
- **Export As** — PNG, JPEG, WebP, JPEG XL, AVIF, GIF, TIFF, BMP or TGA with quality, scale, a preview and the file size. *Where:* File > Export As
- **File Info** — title, author, description, keywords, copyright and URL, kept with the document and written into exported PNG and JPEG files. *Where:* File > File Info (Alt+Shift+Ctrl+I). *Since:* 2.485.0
- **Print** — fit to the page, a size or a percentage, portrait or landscape, then the system's print dialog. *Where:* File > Print (Ctrl+P). *Since:* 2.485.0
- **Contact Sheet** — pictures from files or the open documents in a grid on a new document, one layer each, with captions. *Where:* File > Automate > Contact Sheet. *Since:* 2.485.0
- **Crop and Straighten Photos** — each photo on a scan found, turned straight and opened as its own document. *Where:* File > Automate > Crop and Straighten Photos. *Since:* 2.485.0
- **Auto-Align Layers** — line the picked layers up on one of them: perspective, move / turn / scale, or move only. *Where:* Edit > Auto-Align Layers. *Since:* 2.486.0
- **Auto-Blend Layers** — masks that blend layers into a panorama (soft seams, matched tones) or a focus stack (the sharpest layer at each spot). *Where:* Edit > Auto-Blend Layers. *Since:* 2.486.0
- **Photomerge** — stitch overlapping pictures (files or the open documents) into a panorama document with one masked layer each. *Where:* File > Automate > Photomerge. *Since:* 2.486.0
- **Merge to HDR** — fuse bracketed exposures, lined up first, into one well-exposed picture. *Where:* File > Automate > Merge to HDR. *Since:* 2.486.0
- **Image modes** — Bitmap, Grayscale, Duotone (1-4 inks), Indexed Color (palettes, dither, Color Table with .act files), RGB and CMYK (a press model: paper, black generation, total ink). *Where:* Image > Mode. *Since:* 2.487.0
- **Proof colours and gamut warning** — see the picture as a press would print it and which colours it cannot print; on screen only. *Where:* View > Proof Setup, Proof Colors (Alt+Ctrl+Y), Gamut Warning (Shift+Ctrl+Y). *Since:* 2.487.0
- **CMYK TIFF** — export the four printing inks for a print shop. *Where:* File > Export As > TIFF (CMYK, for print). *Since:* 2.487.0
- **JPEG XL files** — open, place and drop .jxl pictures; export JPEG XL with a quality or lossless; .jxl pictures show everywhere in the app and are sent to ComfyUI and the compile as PNG. *Where:* File > Open, Export As > JPEG XL, the Assets docker. *Since:* 2.479.0
- **Copy and paste** — copy, cut, paste, paste in place, copy merged and system clipboard pictures. *Where:* the Edit menu
- **PSD files** — layers, groups, masks, opacity, blend modes, visibility, layer styles, vector masks and shapes come across both ways. *Where:* File > Open PSD, Save as PSD. *Since:* 2.390.0
- **PSD smart objects kept** — embedded smart objects open as smart objects and are saved back as placed layers. *Where:* PSD files. *Since:* 2.469.0
- **SVG paths and shapes** — export a path as SVG, place an SVG as a shape layer. *Where:* File > Export Path as SVG, Place SVG as Shape Layer. *Since:* 2.421.0
- **PDF files** — a page opens as its picture without its text plus one type layer per line of text; edit with every tool. *Where:* File > Open PDF. *Since:* 2.424.0
- **PDF pages** — add blank pages or another PDF's pages, move pages (buttons or drag) and take pages out; saved in the new order with untouched pages kept as they were. *Where:* the PDF Pages strip, File > Add / Remove PDF Pages. *Since:* 2.488.0
- **Save PDF** — changed pages saved back with real, searchable text; unchanged pages stay vector. *Where:* File > Save PDF, Save as New. *Since:* 2.424.0
- **Embed fonts in PDFs** — each line written in its own font from this computer or the fonts folder, so any alphabet stays real text. *Where:* the Save PDF dialog. *Since:* 2.435.0
- **.bgi project files** — layers, masks, live text, shapes, fills, adjustments, styles, smart objects with their filters, paths, channels, the selection and layer comps kept fully editable, in a zip any unzip opens. *Where:* File > Save Project (Alt+Ctrl+S). *Since:* 2.436.0

### AI in the image editor

- **AI panel** — the model sees the selection plus a context margin and answers as a new layer inside the feathered selection. *Where:* the AI panel
- **Generate** — renders into the selection of the selected layer from the prompt docker; Apply blends it in. *Where:* the AI panel's Generate tab. *Since:* 2.444.0
- **Edit** — follow an instruction with Qwen Image 2.1 edit, typed in the prompt docker. *Where:* the AI panel's Edit tab. *Since:* 2.444.0
- **Refine, Remove and Background** — rework at a strength, remove what is selected, or regenerate everything else. *Where:* the AI panel
- **Expand** — grow the canvas and continue the picture into it. *Where:* the AI panel
- **Results** — make 1 to 4 versions, compare them, apply or discard. *Where:* the AI panel
- **Control layers** — scribble, line art, soft edge, canny, depth, normal, pose or segmentation layers guide the AI through ControlNet. *Where:* the Control panel
- **Compose** — layers as references: put the thing from one layer into the scene of another. *Where:* the AI panel. *Since:* 2.390.0
- **Send to References** — the picked layers go to the reference dock for any render. *Where:* Layer > Send to References. *Since:* 2.390.0
- **References kept** — the reference docker is written to the project as it changes (closing the app keeps it), all its pictures are saved, and F/L, Swap or Text mode no longer drop pictures. *Where:* the reference docker. *Since:* 2.548.0
- **Shared prompt kept as you type** — the StoryBoard's shared prompt is saved a moment after typing, when it is left and on close. *Where:* the StoryBoard > Scenes. *Since:* 2.548.0
- **Generate Fill in Shape or Mask** — generate inside a shape's outline or a layer's mask, clipped to it. *Where:* the Layer menu. *Since:* 2.437.0
- **Generate into a shape** — with a closed shape active the result goes inside it as a frame. *Where:* the AI panel. *Since:* 2.442.0
- **The prompt docker follows the tab** — the Edit tab switches the prompt docker to image editing, the Generate tab to generating into the selection. *Where:* the AI panel. *Since:* 2.451.0
- **Generate from a 3D layer** — a new image made from the 3D view as you see it. *Where:* the 3D tab. *Since:* 2.460.0

## CAD and 3D

Precise drawing with constraints, measuring, CAD files, and parametric 3D bodies built from sketches.

### Sketch layers

- **Sketch layers** — a CAD sketch of lines, rectangles, circles and arcs held in shape by constraints and dimensions, with a fixed origin and two construction axes. *Where:* Layer > New Sketch, or any sketch tool. *Since:* 2.462.0
- **Sketch tools** — Sketch Select, Line, 2-Point and Center Rectangle, Circle, 3-Point Arc, Point and Sketch Dimension, each with its own letter. *Where:* N in the tool column. *Since:* 2.462.0
- **Line chains** — click point after point; nearly level or upright lines snap and get Horizontal or Vertical; ends join where they meet. *Where:* the Line tool. *Since:* 2.462.0
- **Construction geometry** — turn what is picked into dashed construction lines that are never drawn in the picture. *Where:* X. *Since:* 2.462.0
- **Sketch Select** — pick and drag points, lines and circle edges while the constraints hold. *Where:* S with a sketch tool. *Since:* 2.462.0
- **Colours while sketching** — blue is still free, black is fully constrained, orange dashed is construction, grey numbers are driven dimensions. *Where:* the sketch. *Since:* 2.462.0
- **Profiles to shapes** — every closed region becomes a shape layer above the sketch. *Where:* Profiles > Shapes. *Since:* 2.462.0
- **Fill profiles** — the closed regions filled, with the line colour and width you choose. *Where:* the Sketch tab. *Since:* 2.462.0
- **Finish Sketch** — back to the Move tool. *Where:* the Sketch tab. *Since:* 2.462.0
- **Kept in .bgi** — a .bgi keeps every constraint; moving or scaling the layer moves its sketch. *Where:* .bgi files. *Since:* 2.462.0

### Constraints and dimensions

- **Constraints** — Coincident, Collinear, Concentric, Midpoint, Fix, Parallel, Perpendicular, Horizontal, Vertical, Tangent, Equal and Symmetric. *Where:* the Sketch tab. *Since:* 2.462.0
- **Degrees of freedom** — how many are left, with a tick when fully constrained. *Where:* the Sketch tab. *Since:* 2.462.0
- **Over-constraint refused** — a constraint already set by the others is refused, and a dimension becomes a driven one instead. *Where:* the sketch. *Since:* 2.462.0
- **Sketch dimensions** — a line's length, two points' distance, two lines' angle, a circle's diameter or an arc's radius; type the value, sums work. *Where:* D. *Since:* 2.462.0
- **Typed sizes while drawing** — type a length and angle, width and height, diameter or radius as you draw; the values are kept as dimensions. *Where:* any sketch tool. *Since:* 2.464.0

### More sketch tools

- **Polygon** — a centre and a corner, the number of sides, kept on a construction circle. *Where:* the N tools. *Since:* 2.463.0
- **Slot** — two half-circles joined by tangent lines. *Where:* the N tools. *Since:* 2.463.0
- **2-Point and 3-Point Circle** — a circle from a diameter or three points. *Where:* the N tools. *Since:* 2.463.0
- **Spline** — a smooth curve through every point you click. *Where:* the N tools. *Since:* 2.463.0
- **Trim** — cut away the piece of a line, circle or arc between the nearest crossings. *Where:* T. *Since:* 2.463.0
- **Extend** — run a line on to the next line or circle. *Where:* E. *Since:* 2.463.0
- **Fillet and Chamfer** — a tangent arc or a straight cut at a corner, with its value as a dimension. *Where:* F. *Since:* 2.463.0
- **Offset** — a copy at a distance that stays parallel or concentric. *Where:* the Sketch tab > Modify. *Since:* 2.463.0
- **Offset tool** — click a chain, then the pointer picks the side and distance (or type it); lines drawn any way round go out or in together and rounded corners stay joined. *Where:* the Sketch tab > Modify > Offset (O). *Since:* 2.494.0
- **Mirror** — mirrored copies held symmetric about a line. *Where:* the Sketch tab > Modify. *Since:* 2.463.0
- **Rectangular and Circular Patterns** — copies in rows and columns or round a point, with the same constraints. *Where:* the Sketch tab > Modify. *Since:* 2.463.0

### Measure, units and CAD files

- **Measure** — lengths, angles, radii, areas and perimeters of one item, between two, or inside a closed region; copy the numbers. *Where:* M with a sketch tool. *Since:* 2.464.0
- **Units** — pixels, or millimetres and inches with a scale. *Where:* the Sketch tab > Measure and CAD files. *Since:* 2.464.0
- **Export DXF** — an R12 DXF that CAD, laser and CNC programs open, with construction lines and dimensions on their own layers. *Where:* File > Export Sketch as DXF. *Since:* 2.464.0
- **Export SVG** — the sketch at a real size with its lines and profiles. *Where:* File > Export Sketch as SVG. *Since:* 2.464.0
- **Import DXF** — lines, circles, arcs, polylines, splines and ellipses into a sketch, fitted or at real size, ends joined into profiles. *Where:* File > Import DXF. *Since:* 2.464.0

### The CAD toolbar

- **A ribbon toolbar** — tabs over groups of big buttons; each group's name opens every item in it; fold it down to its tabs. *Where:* along the top of the image editor and the timeline. *Since:* 2.470.0
- **Sketch tab** — Create (new sketch, lines, rectangles, circles, arc, polygon, slot, spline, point), Modify (fillet, chamfer, trim, extend, offset, mirror, patterns, construction), the 12 constraints, Inspect (dimension, measure), Insert (DXF in and out, SVG out) and Finish Sketch. *Where:* the CAD toolbar. *Since:* 2.470.0
- **Shapes tab** — Select (the Move tool, pick nothing), Draw (the shape tools) and the after-drawing switch. *Where:* the CAD toolbar. *Since:* 2.470.0
- **The tab follows the work** — picking a sketch tool or sketch layer opens the Sketch tab; a 3D layer opens the 3D tab on the timeline. *Where:* the CAD toolbar. *Since:* 2.470.0
- **Timeline tabs** — Create (text, 3D text, 3D model, camera, path, the canvas tools), 3D (widget, views, key, bake) and Sketch. *Where:* the timeline's CAD toolbar. *Since:* 2.470.0
- **Sketch on a frame** — the frame at the playhead, or a blank picture of the timeline's size, opens in the image editor with a new sketch layer. *Where:* the timeline's Sketch tab. *Since:* 2.470.0
- **Show or hide it** — the toolbar can be kept on or left to show only when needed. *Where:* Window > CAD Toolbar, or the ⌬ CAD buttons. *Since:* 2.470.0
- **The CAD button** — the CAD toolbar shows by itself while a sketch, a sketch tool or a 3D body is picked; the ⌬ CAD button in the tool column keeps it on (the timeline has its own). *Where:* the image editor's and the timeline's tool columns. *Since:* 2.494.0
- **Sketch flow** — Select leads the Sketch tab, Create Sketch hides while a sketch is edited, Finish Sketch goes on to the Solid tab. *Where:* the CAD toolbar. *Since:* 2.494.0
- **Draw on from a line** — a ＋ beyond each end of the picked line starts the Line tool from that end. *Where:* Sketch Select. *Since:* 2.494.0

### Parametric 3D bodies

- **Body layers** — a 3D body drawn from its features as a smart object, so moving, scaling, filters and masks all work. *Where:* the CAD toolbar's Solid tab, Layer > 3D Body. *Since:* 2.471.0
- **Extrude** — a sketch's closed profiles by a distance, one side, symmetric or two sides, as a new body or joined, cut or intersected with one. *Where:* the Solid tab. *Since:* 2.471.0
- **Pick the profile** — Extrude and Revolve let you click the closed regions to use, highlighted under the pointer. *Where:* the Solid tab. *Since:* 2.494.0
- **Revolve** — profiles spun round the sketch's X or Y axis or one of its lines, by an angle. *Where:* the Solid tab. *Since:* 2.471.0
- **Fillet and Chamfer** — round or bevel all, top, bottom, vertical or horizontal edges. *Where:* the Solid tab. *Since:* 2.471.0
- **Shell** — hollow the body, open at the top or bottom. *Where:* the Solid tab. *Since:* 2.471.0
- **Split Body** — cut by a plane; one side stays, the other becomes a new body layer. *Where:* the Solid tab. *Since:* 2.471.0
- **Parameters** — named values and expressions with units (mm, cm, m, in, deg) used by every feature; change one and the body rebuilds. *Where:* the Solid tab's Change Parameters. *Since:* 2.471.0
- **The feature list** — every feature in order: suppress, edit, delete or reorder, with errors in red. *Where:* the Body tab. *Since:* 2.471.0
- **Rebuilds from the sketch** — a sketch edited later rebuilds the bodies made from it. *Where:* body layers. *Since:* 2.471.0
- **Views and orbit** — home, front, top, right, left, back, or drag the body round. *Where:* the Solid tab. *Since:* 2.471.0
- **The view cube and 3D navigation** — click a face or corner of the cube for that view, drag it to orbit; Shift + middle-drag orbits a body, middle-drag pans, the wheel zooms. *Where:* the canvas while a body is picked. *Since:* 2.494.0
- **The look** — colour, metal, roughness and edges, and the view's turn, tilt and roll. *Where:* the Body tab. *Since:* 2.471.0
- **Export STL, glTF and STEP** — the body as a file for printing, 3D apps or CAD. *Where:* the Solid tab > Export. *Since:* 2.471.0
- **Bodies on the timeline** — send a body to the timeline as a 3D layer; it updates by itself when the body changes. *Where:* the timeline's Solid tab. *Since:* 2.471.0
- **Edit in Image Editor** — open the image editor with that body picked. *Where:* the timeline's Solid tab. *Since:* 2.471.0
- **Two engines** — OpenCascade running in the page (exact fillets, booleans and shells, nothing to install) or Blender on this computer. *Where:* Settings > 3D. *Since:* 2.471.0

### 3D layers in the image editor

- **3D layers** — a Daz or Blender scene in a picture, drawn again by Blender whenever its view changes; masks, filters and blend modes work. *Where:* Layer > New 3D Layer. *Since:* 2.460.0
- **A 3D model as a 3D layer** — a .glb / .gltf / .obj / .fbx / .stl from the project's 3D models opens as a 3D layer: Blender puts it in a lit scene with a camera framed on it. *Where:* Layer > New 3D Layer, or 🧊 Convert to 3D. *Since:* 2.594.0
- **Camera** — the scene camera, front, back, left, right or top, or turn, tilt, distance and lens; drag on the canvas to orbit, pan and zoom. *Where:* the 3D tab. *Since:* 2.460.0
- **Pose** — pick a figure and bone and turn it on top of its pose. *Where:* the 3D tab. *Since:* 2.460.0
- **Frame and render** — pick a frame of an animated scene; render it Quick, EEVEE or Cycles, with a transparent background. *Where:* the 3D tab. *Since:* 2.460.0
- **Model** — move, turn, scale or hide the scene's objects, by numbers or by dragging them on the canvas; the .blend is not changed. *Where:* the 3D tab > Model. *Since:* 2.541.0
- **Blender mode** — with a 3D layer picked, the prompt docker's Edit and Refine render the scene with Blender and work from that picture; the results come into the AI panel, and ✔ keeps one as a layer. *Where:* the prompt docker's dropdown. *Since:* 2.541.0
- **Blender layer** — the timeline's Blender scene tools over the image editor's canvas (open a .blend, scene camera or free view, move / rotate / scale objects, save); the view becomes a layer, and Edit in the prompt docker makes a new layer from the scene. *Where:* the editor's 🟧 button, or Layer > New Blender Layer. *Since:* 2.542.0
- **Reference pictures with a Blender scene** — name a References docker picture in the prompt ("the face of the woman in picture 1") and it goes to the edit model with the scene; the numbers and the word are changed to the model's own (image 2, <image2>, Picture 2). *Where:* the 🟧 Blender tab > References. *Since:* 2.546.0
- **Built-in styles back** — ↺ Built-in lists the built-in image or video styles that are missing and puts them back; the Krea 2 styles come back once on their own. *Where:* Settings > Image styles / Video styles. *Since:* 2.547.0
- **Zoom in the Blender view** — 🔍＋ / 🔍－, Alt+drag (forward = in, back = out) and ⌖ Zoom to object (Z); in the image editor the player bar and Auto-key are left out. *Where:* the Blender scene tools' buttons. *Since:* 2.546.0
- **Rigged figures picked by their rig** — a click on a skinned body picks its armature, so moving it moves the figure (not just the widget). *Where:* the Blender scene tools (timeline and image editor). *Since:* 2.550.0

### 3D scenes and models from pictures

- **Image to 3D** — Hunyuan3D 2.1 (shape) or TRELLIS.2 (shape and texture) make a .glb from any picture. *Where:* the 3D button on Gallery and Assets pictures. *Since:* 2.404.0
- **Build a scene with AI** — the local LLM plans a 3D scene from 58 kinds of object, a camera path and 3D models for the rest; Blender builds it. *Where:* the Blender preview's Build button. *Since:* 2.404.0

### PushPull modelling

- **📏 PushPull docker** — quick 3D modelling in bitGen: draw shapes on the ground or on faces and push / pull them into solids; models kept in the project, saved as you work, undo / redo. *Where:* the status bar's PushPull button (it starts hidden). *Since:* 2.619.0
- **Push / pull** — a face becomes a solid; the top of a box makes it taller; a shape drawn on a face goes in (a pocket) or out (a boss); pushed to the far side, a hole through; a line across a face splits it. *Where:* PushPull ▸ P. *Since:* 2.619.0
- **Exact sizes and snapping** — type lengths (m, cm, mm, feet, inches), two sizes, sides or degrees at any moment; the pointer snaps to corners, midpoints, edges, faces, the origin and the red / green / blue axes (arrows or Shift keep one). *Where:* PushPull ▸ the Measurements box. *Since:* 2.619.0
- **Lines, rectangles, circles, polygons, offset** — the drawing tools; Offset makes a loop inside a face (walls round a room, frames). *Where:* PushPull ▸ L / R / C / N / F. *Since:* 2.619.0
- **Move, copy, rotate, scale, groups, paint, erase, tape** — the editing tools; Ctrl+Move copies; groups are picked as one and edited inside with a double-click. *Where:* PushPull ▸ M / Q / S / G / B / E / T. *Since:* 2.619.0
- **Views and styles** — Iso / Top / Front / Right / Back / Left, perspective or parallel, everything in view, shaded / monochrome / X-ray / wireframe, shadows. *Where:* PushPull's bar. *Since:* 2.619.0
- **PushPull into bitGen** — a picture of the view into the image editor, a 3D layer on the timeline, a piece in the House builder, a scene in Blender, a mesh in Unreal; .glb / .obj / .stl export; project 3D models imported as groups. *Where:* PushPull ▸ Send / Export / Import. *Since:* 2.619.0
- **Rooms that share walls** — a room is drawn with two clicks (walls, floor, ceiling); dragged near another room its wall snaps onto the other's and the two share one wall; each wall face takes the colour of the room it faces. *Where:* PushPull ▸ Build ▸ U Room, then Select + drag. *Since:* 2.620.0
- **Walls, floors, ceilings, stairs** — free-standing walls (closed into a room when they meet their start), floors without walls, a room's ceiling on / off, straight stairs. *Where:* PushPull ▸ Build ▸ W / J / K / V. *Since:* 2.620.0
- **Doors and windows** — single, double, sliding and glass doors or a plain opening; one-pane, two-pane and sliding windows with a sill; a click on any wall (through a shared wall too), dragged along it, sized in the panel. *Where:* PushPull ▸ Build ▸ D / I. *Since:* 2.620.0
- **Roofs** — gable, hip, shed or flat over one room or several, with pitch, overhang and thickness; the gable ends walled up. *Where:* PushPull ▸ Build ▸ Y Room roof (Shift+click adds rooms). *Since:* 2.620.0
- **Lights** — downlights, ceiling-mounted lights, pendants, chandeliers, spots, wall lights, floor and table lamps, each a real light with its fixture, colour (warm to cool) and brightness; 🌙 Night shows what they light; exported as glTF lights. *Where:* PushPull ▸ Build ▸ X Light, the bar's 🌙 Night. *Since:* 2.620.0
- **The building's panel** — whatever is picked, or the next one the tool makes: sizes, heights, styles, colours, duplicate, turn, roof, delete. *Where:* PushPull ▸ the panel on the right. *Since:* 2.620.0
- **Walls on a floor** — the Room / Wall tools' Offset from floor edge (the outside face that far in from a floor's edge); drag one wall of a room (the room stretches) - the floors' snap regions show and it snaps onto an edge; rooms snap to floor edges too. *Where:* PushPull ▸ U / W, Select. *Since:* 2.624.0
- **Sloped walls** — double-click a wall's top for a cut, drag it up / down (a gable end); pick a top edge and drag it or type its heights (a shed wall); Delete takes a cut / an edge away. *Where:* PushPull ▸ Select. *Since:* 2.624.0
- **Ceilings and roofs that follow the walls** — a room's ceiling None / Flat / Follows the walls' slope; a roof that follows them with an eaves width. *Where:* PushPull ▸ a room's panel, Y Roof. *Since:* 2.624.0
- **PushPull in bitGen's colours; double-click empty = Orbit** — the docker and its 3D view use the theme's colours; a double-click on nothing deselects everything and orbits. *Where:* PushPull. *Since:* 2.624.0
- **PushPull's own window and File menu** — ⛶ fills the whole bitGen window under the title bar (then ⇲ Dock puts it back, 2.624.0), ✕ closes it; ☰ File: new, open, save, save as, rename, import, export, send, delete, close; 🖼 → Image editor and 🎞 → Timeline buttons; ⌂ Cut-away. *Where:* PushPull's title bar and bar. *Since:* 2.620.0

## Bridges

Live links to Blender, Daz Studio and Unreal Engine 5.8, all on the same computer.

### Blender

- **The Blender add-on** — a bitGen tab in Blender's sidebar: send a scene or selection as glTF (or as a 3D layer), a live link that re-sends on every save, and get the project's 3D models into Blender. *Where:* Blender's sidebar (N). *Since:* 2.385.0
- **Render scene to real** — renders a Blender layout through its camera and has LTX 2.3 with 3DREAL make it photoreal. *Where:* the add-on's Render scene button. *Since:* 2.402.0
- **A .blend in the preview canvas** — open a .blend over the timeline canvas: look through its camera or a free view, select, move, key, duplicate, hide and delete objects. *Where:* the Blender button in the canvas tools. *Since:* 2.403.0
- **Segments and saving** — set an In and Out, save only in bitGen, back to the original, or to a new file. *Where:* the .blend preview's Properties. *Since:* 2.403.0
- **Render to real from the preview** — render the segment and queue an LTX 2.3 3DREAL job. *Where:* the .blend preview. *Since:* 2.403.0
- **Add models** — add a project 3D model to the open scene. *Where:* the .blend preview's Properties. *Since:* 2.404.0
- **Poses in the preview** — turn a figure's bones; Blender keys the pose on save and render. *Where:* the .blend preview's Pose section. *Since:* 2.461.0
- **To the image editor** — the scene as a 3D layer with this pose and view. *Where:* the .blend preview. *Since:* 2.461.0

### Daz Studio

- **The bitGen Bridge script** — render the animation to real, render a frame to a picture, send the scene as 3D to open or merge, or a figure as a 3D model. *Where:* Daz Studio's Scripts > bitGen. *Since:* 2.405.0
- **The Merge dialog** — pick the figures, lights and cameras to merge into the open scene, the scene camera and the frame range. *Where:* bitGen, when a Daz scene arrives. *Since:* 2.405.0
- **Daz scenes as 3D layers** — send a scene and open it as a 3D layer in the image editor. *Where:* bitGen Bridge > Scene. *Since:* 2.460.0
- **The live link (experimental)** — bitGen moves the camera and poses in Daz Studio itself. *Where:* Daz Studio's bitGen Live Link, the 3D tab, the timeline's Pose section. *Since:* 2.461.0

### Unreal Engine 5.8

- **The bitGen Bridge plugin** — a Python-only plugin for the Unreal Editor that lists the project's levels, Level Sequences, cameras, MetaHumans and animations, answering only on this computer. *Where:* the project's Plugins folder. *Since:* 2.472.0
- **Unreal settings** — the port, an "alpha is inverted" switch, Test connection and how to install the plugin. *Where:* Settings > 3D > Unreal Engine. *Since:* 2.472.0
- **Unreal layers in the image editor** — a level seen through one of its cameras, or the level viewport as it is now, as a picture layer. *Where:* the CAD toolbar's Unreal tab, Layer > New Unreal Layer. *Since:* 2.472.0
- **MetaHuman layers in the image editor** — a MetaHuman in the pose of an animation at a time, framed face, bust or full body, turned, on a clear background. *Where:* the Unreal tab, Layer > New MetaHuman Layer. *Since:* 2.472.0
- **The Unreal tab** — nudge the camera's turn, tilt, dolly and field of view (or the figure's turn, pose time and framing), use the viewport now, render again. *Where:* the layer's Unreal tab in Properties. *Since:* 2.472.0
- **Unreal layers on the timeline** — a Level Sequence, or a level through a camera for a length you pick, rendered by the Movie Render Queue at the timeline's size and frame rate. *Where:* the timeline's Unreal tab. *Since:* 2.472.0
- **MetaHuman layers on the timeline** — a MetaHuman playing an animation on a clear background, over the other layers. *Where:* the timeline's Unreal tab. *Since:* 2.472.0
- **The Unreal camera** — your own camera with keys of time, place, turn and field of view taken from Unreal's viewport or cameras, rendered through the level. *Where:* the timeline's Unreal tab. *Since:* 2.472.0
- **Render again** — each clip remembers how it was made and renders anew after the Unreal project or the keys change. *Where:* the Unreal tab. *Since:* 2.472.0
- **The Unreal camera tool** — move the camera of an Unreal or MetaHuman layer in the scene: drag to orbit, Ctrl to look, Shift to pan, Alt to roll, the wheel to dolly, Ctrl+wheel to zoom; small previews while dragging. *Where:* the image editor's UNREAL tab, Camera. *Since:* 2.475.0
- **The Camera tab** — lens presets (18-200 mm, macro, anamorphic, your own), focal length linked to the field of view, filmback, f-stop and focus distance (depth of field, click to focus), exposure (EV), place and roll / pitch / yaw, to and from Unreal's viewport. *Where:* Properties, Window > Unreal Camera. *Since:* 2.475.0
- **The timeline camera's lens** — focal length, f-stop, focus and exposure for an Unreal camera's render. *Where:* the timeline's UNREAL tab, Keys. *Since:* 2.475.0
- **Unreal lights** — point, spot, rect (softbox), sun and sky lights with colour or temperature, intensity, reach, cone, size, volumetric scattering and shadows; presets (three-point, golden hour, night street, neon, softbox). *Where:* the image editor's Lights tab, UNREAL > Lights & Fog. *Since:* 2.476.0
- **Fog and volumetric fog** — exponential height fog (density, falloff, colour, start) with volumetric fog (albedo, extinction, distance) and fog presets. *Where:* the Lights tab, the timeline's Lights & Fog. *Since:* 2.476.0
- **The light tool** — each light as a marker on the picture: drag it across, Shift-drag nearer or further, Alt-drag its aim. *Where:* the image editor's UNREAL tab, Lights. *Since:* 2.476.0
- **Lights on the timeline** — the same lights and fog for an Unreal, MetaHuman or Unreal camera clip, or the image editor's ones brought over. *Where:* the timeline's UNREAL tab, Lights & Fog. *Since:* 2.476.0

## Delivery and formats

Getting the work out: movies in every format, files for other editors, and bitGen's own project files.

### Compile and export

- **Compile** — the timeline into one movie in the project folder. *Where:* the timeline
- **Export formats** — MP4 H.264, H.265, H.265 10-bit, H.264 10-bit and AV1; MOV ProRes 422 HQ, ProRes 4444 with alpha and DNxHR HQ; WebM VP9; GIF; WAV and MP3. *Where:* the Export dialog. *Since:* 2.407.0
- **One compile, every format** — size, reframe (crop, pad or blur), frame rate and quality per format; packs add several at once. *Where:* the Export dialog. *Since:* 2.407.0
- **Smart reframe** — a vertical or square version whose crop follows the subject. *Where:* the Export dialog's fit. *Since:* 2.413.0
- **HDR output** — HDR10, HLG or Rec.2020 on the 10-bit presets. *Where:* the Export dialog. *Since:* 2.417.0
- **Graphics card encoders** — NVENC, Quick Sync, AMF or VAAPI when one works here. *Where:* the Export dialog. *Since:* 2.411.0
- **In / Out export and frames** — export just the ruler selection, or the frame at the marker as a PNG. *Where:* the Export dialog, Ctrl+Shift+E. *Since:* 2.410.0
- **Loudness targets** — -14, -16, -23 or -24 LUFS. *Where:* the Mix dialog. *Since:* 2.406.0
- **Captions out** — burned in, or an .srt beside each movie. *Where:* the Captions dialog. *Since:* 2.406.0

### Exchange with other editors

- **Final Cut Pro 7 XML** — clips, trims, layers, speed, moves, keyframes, opacity, volume, captions, markers and the grade as .cube LUTs; out and in. *Where:* the Exchange dialog. *Since:* 2.407.0
- **FCPXML 1.10** — for Final Cut Pro X, both ways. *Where:* the Exchange dialog. *Since:* 2.414.0
- **EDL and OpenTimelineIO** — CMX3600 EDL (V1) and OTIO, with markers. *Where:* the Exchange dialog. *Since:* 2.407.0
- **AAF** — the cut for Avid Media Composer and Pro Tools. *Where:* the Exchange dialog. *Since:* 2.417.0
- **Bring in a timeline** — an XML or EDL opens as a new named timeline, clips matched by name. *Where:* the Exchange dialog. *Since:* 2.407.0

### bitGen's own files

- **.bgi** — the image editor's project, a zip of XML and PNGs. *Where:* the image editor's File menu. *Since:* 2.436.0
- **.bgv** — a timeline with every layer, clip, keyframe, effect, caption, marker and its nested timelines, as XML. *Where:* the timeline toolbar. *Since:* 2.436.0
- **.bgp** — the whole project, self-contained or as a manifest. *Where:* the menu bar. *Since:* 2.436.0
- **CAD and 3D files** — DXF and SVG sketches; STL, glTF and STEP bodies. *Where:* the CAD toolbar. *Since:* 2.464.0
- **VR files** — VR videos carry spherical metadata and the players' name suffixes. *Where:* VR World and the swap

### Guides

- **The PDF guide** — the step-by-step instructions plus a one-page view of every shortcut key, in the studio's dark theme. *Where:* docs/bitGen-Studio-Guide.pdf. *Since:* 2.391.1
- **The brochure** — a 3-page brochure. *Where:* docs/bitGen-Studio-Brochure.pdf. *Since:* 2.392.0
- **The Feature Reference** — this catalogue of every feature by area (what it does, where it is, since which version), made again for every release. *Where:* docs/bitGen-Studio-Features.pdf. *Since:* 2.473.0
- **In-app help** — help pages for the timeline and the image editor. *Where:* the Help buttons. *Since:* 2.380.0

## Keyboard shortcuts

The full list of keys is in the PDF guide (docs/bitGen-Studio-Guide.pdf) and in the image editor's Help > Keyboard Shortcuts.

### The most used keys

- **P, S, L, 2, 1** — the prompt docker, Basic Settings, LLM tokens, the negative prompt docker and Tools and Properties. *Where:* anywhere (not while typing)
- **Space, J, K, L** — pause and play; shuttle backwards, stop and forwards. *Where:* the timeline
- **V, B, N, Y, U** — the timeline's Select, Ripple, Roll, Slip and Slide tools. *Where:* over the timeline's layers
- **Ctrl+K, M, I, O** — split, marker, In and Out. *Where:* the timeline
- **F5, F6, F8, F10, F12, Ctrl+Q** — curve tools, shape tools, dimensions, the node Shape tool, the Outline Pen, Convert to Curves. *Where:* the image editor
- **N, then S, L, R, C, A, P, D, X, T, E, F, M** — the sketch tools and their letters. *Where:* the image editor
- **Alt+Shift+S, Alt+Shift+R** — screenshot and screen recording. *Where:* anywhere
